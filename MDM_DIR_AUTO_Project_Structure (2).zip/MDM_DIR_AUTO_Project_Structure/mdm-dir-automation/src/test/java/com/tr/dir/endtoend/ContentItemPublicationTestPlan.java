package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.ContentItemPublicationUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class ContentItemPublicationTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-ContentItemPublication.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ContentItemPublicationUtil cipUtil = new ContentItemPublicationUtil();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(ContentPublishingServiceTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(ContentPublishingServiceTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"validateMappingForContentItemPublication", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validateMappingForContentItemPublication(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        driver.findElement(homePage.objectTypeMapping).click();
        Assert.assertFalse(uiUtils.getAllObjectTypes(driver).contains(testData.getEntity()), "ContentItemPublication is added on ObjectType mapping!!");

    }

    @Test(groups = {"createContentItemPublicationEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentItemPublicationEntity(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentItemPublication);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        cipUtil.fillContentItemPublicationDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);
        String entityIdInDB = util.isEntityIdExistsInDB("CONTENT_ITEM_PUBLICATION", createdEntityId, "CI_PUB_ID");

        Assert.assertEquals(createdEntityId, entityIdInDB, "EntityId not stored in DB !!");

    }

    @Test(groups = {"modifyContentItemPublicationEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyContentItemPublicationEntity(TestObject testObject, DIRBean testData) {

        createdEntityId = Util.getProperty("CONTENT_ITEM_PUBLICATION_ENTITY_ID");
        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentItemPublication);
        enterText(driver, entityDetails.searchEntityId, createdEntityId);
        clickElement(driver, entityDetails.entitySearchButton);

        clickElement(driver, entityDetails.selectEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        enterText(driver, entityDetails.jobName2, uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));
        enterText(driver, entityDetails.sourceNote, testData.getSourceNote());
        enterText(driver, entityDetails.comments, testData.getComments());
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String entityIdInDB = util.isEntityIdExistsInDB("CONTENT_ITEM_PUBLICATION", createdEntityId, "CI_PUB_ID");

        Assert.assertEquals(createdEntityId, entityIdInDB, "EntityId not stored in DB !!");

    }

    @Test(groups = {"createContentItemPublicationEntityWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentItemPublicationEntityWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentItemPublication);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        cipUtil.fillContentItemPublicationDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        Assert.assertEquals(getText(driver, entityDetails.cipErrorMessage), "Name field is required", "Not showing error message for mandatory fields!!");

    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }


}
