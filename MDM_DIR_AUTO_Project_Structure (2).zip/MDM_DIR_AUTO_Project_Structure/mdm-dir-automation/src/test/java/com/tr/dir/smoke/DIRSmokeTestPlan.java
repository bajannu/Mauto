package com.tr.dir.smoke;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.UiUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.*;

/**
 * @author Santosh C
 */
public class DIRSmokeTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/smoke/EcpTestData.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    public static final Logger logger = LoggerFactory.getLogger(DIRSmokeTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(DIRSmokeTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"checkAllTabsInHomePage", "SmokeTests"}, dataProvider = DATAPROVIDER_NAME)
    public void checkAllTabsInHomePage(TestObject testObject) {

        logger.info("Test Steps: " + testObject.getTestSteps());

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Assert.assertTrue(driver.findElement(homePage.home).isDisplayed(), "'Home' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.jobManagement).isDisplayed(), "'Job Management' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.jobReport).isDisplayed(), "'Job Report' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.qualityReport).isDisplayed(), "'Quality Report' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.relationshipEditor).isDisplayed(), "'Relationship Editor' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.contentItemEditor).isDisplayed(), "'DIRBean Editor' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.sqlRunner).isDisplayed(), "'SQL Runner' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.logViewer).isDisplayed(), "'Log Viewer' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.rdfMapping).isDisplayed(), "'RDF Mapping' tab is not visible in HomePage!!");

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        Assert.assertTrue(driver.findElement(homePage.ecpServiceMapping).isDisplayed(), "'ECP Service Mapping' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.ecpServiceRegistration).isDisplayed(), "'ECP Service Registration' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.objectTypeMapping).isDisplayed(), "'Object Type Mapping' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.objectMapping).isDisplayed(), "'Object Mapping' tab is not visible in HomePage!!");
        Assert.assertTrue(driver.findElement(homePage.rdfLookup).isDisplayed(), "'RDF Lookup' tab is not visible in HomePage!!");

    }

    @Test(groups = {"checkForDropdownValues", "SmokeTests"}, dataProvider = DATAPROVIDER_NAME)
    public void checkForDropdownValues(TestObject testObject) {

        logger.info("Test Steps: " + testObject.getTestSteps());

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        driver.findElement(homePage.contentItem).click();
        Assert.assertTrue(driver.findElement(entityDetails.entityType).isDisplayed(), "Entity Details dropdown is not visible in Entity Details page");

        Select select = new Select(driver.findElement(entityDetails.entityType));
        List<WebElement> entityTypes = select.getOptions();
        List<String> actualEntityTypeValues = new ArrayList<String>();
        for (WebElement item : entityTypes) {
            actualEntityTypeValues.add(item.getText());
        }
        String[] expectedEntityTypeValues = testObject.getTestData().split(",");

        for (int i = 0; i < expectedEntityTypeValues.length; ++i) {
            Assert.assertTrue(actualEntityTypeValues.contains(expectedEntityTypeValues[i]), expectedEntityTypeValues[i] + " Missing EntityType dropdown value");
        }

        Assert.assertTrue(driver.findElement(entityDetails.entityID).isDisplayed(), "EntityId textbox not visible");
        Assert.assertTrue(driver.findElement(entityDetails.identifierType).isDisplayed(), "IdentifierType dropdown not visible");
        Assert.assertTrue(driver.findElement(entityDetails.entityName).isDisplayed(), "EntityName textbox not visible");
        Assert.assertTrue(driver.findElement(entityDetails.identifierValue).isDisplayed(), "IdentifierValue dropdown not visible");
        Assert.assertTrue(driver.findElement(entityDetails.addNewEntity).isDisplayed(), "AddNewEntity button not visible");

    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}
