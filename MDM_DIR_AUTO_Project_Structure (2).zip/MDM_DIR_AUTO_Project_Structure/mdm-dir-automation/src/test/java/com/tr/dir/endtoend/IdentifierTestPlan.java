package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.IdentifierUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * @author  Mattz
 */
public class IdentifierTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-Identifier.csv";
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    IdentifierUtil idenUtil = new IdentifierUtil();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    String createdEntityId = "";
    String createdEntityIdWOMF = "";
    public static final Logger logger = LoggerFactory.getLogger(IdentifierTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(IdentifierTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"createIdentifierEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createIdentifierEntity(TestObject testObject, DIRBean testData) throws InterruptedException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.identifier).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);

        idenUtil.fillIdentifierEntityDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        String actual_entityIDFromDB = util.isEntityIdExistsInDB("IDENTIFIERS",createdEntityId, "IDENTIFIER_ID");
        logger.info("Entity ID Value from DB: " + actual_entityIDFromDB);
        Assert.assertEquals(createdEntityId,actual_entityIDFromDB);

    }

    @Test(groups = {"modifyIdentifierEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyIdentifierEntity(TestObject testObject, DIRBean testData) throws InterruptedException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        String identifierModifyValue = String.valueOf(System.currentTimeMillis());
        driver.findElement(homePage.identifier).click();

        driver.findElement(entityDetails.generalEntitySearch).sendKeys(createdEntityId);
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.findElement(entityDetails.search).click();
        driver.findElement(entityDetails.identifierSelectResult).click();
        Util.sleep(DEFAULT_WAIT_TIME);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        driver.findElement(entityDetails.jobName2).sendKeys(uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));

        driver.findElement(entityDetails.identifierIDValue).click();
        driver.findElement(entityDetails.identifierIDValue).clear();
        driver.findElement(entityDetails.identifierIDValue).sendKeys(identifierModifyValue);

        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_entityIDValueFromDB = util.isEntityIdExistsInDB("IDENTIFIERS",createdEntityId, "ID_VALUE");
        logger.info("Entity ID Value from DB: " + actual_entityIDValueFromDB);
        Assert.assertEquals(identifierModifyValue,actual_entityIDValueFromDB);


    }

    @Test(groups = {"createIdentifierWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createIdentifierWithoutMandatoryFields(TestObject testObject, DIRBean testData) throws InterruptedException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.identifier).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityIdWOMF = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityIdWOMF, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityIdWOMF);

        idenUtil.fillPartialIdentifierEntityDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        String errorMessage = driver.findElement(entityDetails.identifierErrorMessage).getText();
        Assert.assertTrue(errorMessage.contains("field is required"), "Not showing error message if we don't provide mandatory details while creating entity!!");
        driver.close();
    }


    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}
