package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.ContentItemUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author Santosh C
 */
public class ContentItemTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-ContentItem.csv";
    final static String REGISTRY_ONTOLOGY = "<http://registry.ecp.ontology.thomsonreuters.com/cmp";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    ContentItemUtil ciUtil = new ContentItemUtil();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(ContentItemTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(ContentItemTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"createContentItemEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentItemEntity(TestObject testObject, DIRBean testData) throws IOException {

        logger.info("TestSteps: " + testObject.getTestSteps());
        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        createdEntityId = ciUtil.createContentItem(driver, testData);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB," RDF Data not generating in DB!! Sample EntityId: "+createdEntityId);
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        ciUtil.validateContentItem(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        /*String graphUri = util.getDbData(createdEntityId, "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        ciUtil.validateContentItem(createdEntityId, actual_MockupServiceResponse, testData);*/
    }

    @Test(groups = {"createContentItemEntityWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentItemEntityWithoutMandatoryFields(TestObject testObject, DIRBean testData) {
        logger.info("TestSteps: " + testObject.getTestSteps());
        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentItem);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);

        ciUtil.fillContentItemEntityDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);

        String errorMessage = getText(driver, entityDetails.errorMessage);
        Assert.assertTrue(errorMessage.contains("field is required"), "Not showing error message if we don't provide mandatory details while creating entity!!");
        driver.close();
    }

    @Test(groups = {"createContentItemEntity_ExistingJob", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentItemEntity_ExistingJob(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentItem);
        clickElement(driver, entityDetails.addNewEntity);
        clickElement(driver, entityDetails.existingJobCheckbox);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectAJob);

        clickElement(driver, entityDetails.selectAJob);
        Util.sleep(5);
        driver.switchTo().window(Util.switchToSecondWindow(driver));

        Util.waitUntil(driver, entityDetails.entityID2);
        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        ciUtil.fillContentItemDetails(driver, uniqueJobName, testData);
        ciUtil.addNameTypes(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        ciUtil.mapCreatedEntityToService(driver, createdEntityId);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB," RDF Data not generating in DB!! Sample EntityId: "+createdEntityId);
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        ciUtil.validateContentItem(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

       /* String graphUri = util.getDbData(createdEntityId, "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        ciUtil.validateContentItem(createdEntityId, actual_MockupServiceResponse, testData);*/
    }

    @Test(groups = {"addRecordInContentItemRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addRecordInContentItemRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.contentItemObjectType);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.addRDFMappingDetails(driver, testData);
        clickElement(driver, homePage.home);

        createdEntityId = ciUtil.createContentItem(driver, testData);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB," RDF Data not generating in DB!! Sample EntityId: "+createdEntityId);

        Assert.assertTrue(actual_RdfDataFromDB.contains(testData.getXmlNamespace()), "XML Namespace field not showing in RDF_RESULT table");
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"modifyRecordInContentItemRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyRecordInContentItemRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.contentItemObjectType);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        driver.findElement(homePage.home).click();

        createdEntityId = ciUtil.createContentItem(driver, testData);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB," RDF Data not generating in DB!! Sample EntityId: "+createdEntityId);
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        Assert.assertTrue(actual_RdfDataFromDB.contains(REGISTRY_ONTOLOGY + "/qedtest>"), "XML Namespace field not showing in RDF_RESULT table");
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"verifyFormulaInContentItemRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void verifyFormulaInContentItemRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.contentItemObjectType);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        clickElement(driver, homePage.home);

        createdEntityId = ciUtil.createContentItem(driver, testData);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        System.out.println("DB DATA: " + actual_RdfDataFromDB);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        ArrayList<String> objectTypeMappingList =  util.getObjectTypeMappingDB(testData);
        ciUtil.validateDBObjectTypeMapping(objectTypeMappingList,actual_RdfDataFromDB);

        if (testData.getPropertyName().equals("NamespaceID")) {
            //Assert.assertTrue(actual_RdfDataFromDB.contains(REGISTRY_ONTOLOGY + "/hasNamespace> <ecp:9"), "Namespace field not showing in RDF_RESULT table");
        }
        if (testData.getPropertyName().equals("Comments")) {
            //Assert.assertTrue(actual_RdfDataFromDB.contains(REGISTRY_ONTOLOGY + "/qedtest"), "SrcNote field not showing in RDF_RESULT table");
            //TODO
        }
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}
