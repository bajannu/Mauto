package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.RelationshipUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * @author Mattz
 */
public class RelationshipTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-Relationship.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    Util util = new Util();
    RelationshipUtil relUtils = new RelationshipUtil();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    String createdEntityId = "";
    String createdEntityIdWOMF = "";
    public static final Logger logger = LoggerFactory.getLogger(RelationshipTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(RelationshipTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"createRelationshipEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createRelationshipEntity(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.relationship).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);

        relUtils.fillRelationshipDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_entityIDFromDB = util.isEntityIdExistsInDB("RELATIONSHIPS", createdEntityId, "RELATIONSHIP_ID");
        logger.info("Entity ID Value from DB: " + actual_entityIDFromDB);
        Assert.assertEquals(createdEntityId, actual_entityIDFromDB);

    }

    @Test(groups = {"modifyRelationshipEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyRelationshipEntity(TestObject testObject, DIRBean testData) {

        //String entityId = "1003451136";
        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        String sourceNoteModifyValue = String.valueOf(System.currentTimeMillis());
        driver.findElement(homePage.relationship).click();
        driver.findElement(entityDetails.generalEntitySearch).sendKeys(createdEntityId);
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.findElement(entityDetails.search).click();
        driver.findElement(entityDetails.relationshipSelectResult).click();
        Util.sleep(DEFAULT_WAIT_TIME);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        driver.findElement(entityDetails.jobName2).sendKeys(uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));

        driver.findElement(entityDetails.relTypeSourceNote).sendKeys(sourceNoteModifyValue);

        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_entityIDFromDB = util.isEntityIdExistsInDB("RELATIONSHIPS", createdEntityId, "RELATIONSHIP_ID");
        logger.info("Entity ID Value from DB: " + actual_entityIDFromDB);
        Assert.assertEquals(createdEntityId, actual_entityIDFromDB);

    }

    @Test(groups = {"relationshipWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void relationshipWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.relationship).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityIdWOMF = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityIdWOMF, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityIdWOMF);

        entityDetails.sendToJob(driver);
        String errorMessage = driver.findElement(entityDetails.relationshipErrorMessage).getText();
        Assert.assertTrue(errorMessage.contains("field is required"), "Not showing error message if we don't provide mandatory details while creating entity!!");
        driver.close();
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}
