package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.DataElementKeyUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class DataElementKeyTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-DataElementKey.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    DataElementKeyUtil dekUtil = new DataElementKeyUtil();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(DataElementKeyTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(DataElementKeyTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"validateMappingForDataElementKey", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validateMappingForDataElementKey(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        driver.findElement(homePage.objectTypeMapping).click();
        Assert.assertTrue(uiUtils.getAllObjectTypes(driver).contains(testData.getEntity()), "DataElementID is not added on ObjectType mapping!!");

    }

    @Test(groups = {"createDataElementKeyEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createDataElementKeyEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElementKey);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        //Util.setProperty("DATA_ELEMENT_KEY_ENTITY_ID", createdEntityId);

        dekUtil.fillDataElementKeyDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        dekUtil.validateDataElementKey(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

    }

    @Test(groups = {"modifyDataElementKeyEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyDataElementKeyEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElementKey);

        String existingDataElementKeyId = Util.getProperty("DATA_ELEMENT_KEY_ENTITY_ID");
        enterText(driver, entityDetails.searchEntityId, existingDataElementKeyId);
        clickElement(driver, entityDetails.entitySearchButton);
        clickElement(driver, entityDetails.selectEntity);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        enterText(driver, entityDetails.jobName2, uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));
        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        enterText(driver, entityDetails.sourceNote, testData.getSourceNote());
        enterText(driver, entityDetails.comments, testData.getComments());

        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        dekUtil.validateDataElementKey(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"createDataElementKeyWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createDataElementKeyWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElementKey);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        enterText(driver, entityDetails.dataElementName, testData.getName1());

        entityDetails.sendToJob(driver);

        String errorMessage = getText(driver, entityDetails.dataElementKeyErrorMessage);
        Assert.assertEquals(errorMessage, "Namespace field is required", "Not showing error message!!");

    }

    //@Test(groups = {"addRecordInDataElementKeyRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addRecordInDataElementKeyRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.dataElementKey);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        clickElement(driver, homePage.home);
        clickElement(driver, homePage.dataElementKey);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        //Util.setProperty("DATA_ELEMENT_KEY_ENTITY_ID", createdEntityId);

        dekUtil.fillDataElementKeyDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        dekUtil.validateDataElementKey(createdEntityId, actual_RdfDataFromDB, testData);

        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        ArrayList<String> objectTypeMappingList =  util.getObjectTypeMappingDB(testData);
        dekUtil.validateDBObjectTypeMapping(objectTypeMappingList,actual_RdfDataFromDB);
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}

