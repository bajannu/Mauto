package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.PresentationCategoryUtils;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by UX012929 on 7/12/2018.
 */
public class PresentationCategoryTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-PresentationCategoryTestData.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    PresentationCategoryUtils presentationCategoryUtils = new PresentationCategoryUtils();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(PresentationCategoryTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(ContentItemTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }


    @Test(groups = {"validatePresentationCategoryEntityInObjectTypeMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validatePresentationCategoryEntityInObjectTypeMapping(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        uiUtils.mouseHover(driver,homePage.rdfMapping);
        driver.findElement(homePage.objectTypeMapping).click();

        List<String> listOfEntitiesFromObjectTypeMapping =  uiUtils.getAllObjectTypes(driver);
        System.out.println(listOfEntitiesFromObjectTypeMapping);
        Assert.assertTrue(listOfEntitiesFromObjectTypeMapping.contains("PresentationCategory"));

    }

    @Test(groups = {"createPresentationCategoryEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createPresentationCategoryEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = uiUtils.login(driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.presentationCategory).click();
        DIRBean testDataFromPresentationCategoryCreation =    presentationCategoryUtils.createPresentationCategoryEntity(testObject,testData,driver);
        Util.sleep(25);
        String actual_RdfDataFromDB = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        /*String graphUri = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getUniqueName()));*/
    }

    @Test(groups = {"modifyPresentationCategoryEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyPresentationCategoryEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.presentationCategory).click();

        DIRBean testDataFromPresentationCategoryCreation =    presentationCategoryUtils.createPresentationCategoryEntity(testObject,testData,driver);
        String actual_RdfDataFromDB = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

       /* String graphUri = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getUniqueName()));*/

    }

    @Test(groups = {"createPresentationCategoryWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createPresentationCategoryWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.presentationCategory).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        System.out.println("EntityID"+createdEntityId);
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);



        entityDetails.sendToJob(driver);
        String errorMessageForUniqueName = driver.findElement(entityDetails.getErrorMessageForMissingUniqueNameForPresentationCategory).getText();
        Assert.assertTrue(errorMessageForUniqueName.contains("Unique Name field is required"));

        driver.findElement(entityDetails.entityUniqueName).sendKeys(uniqueJobName);
        entityDetails.sendToJob(driver);

        String errorMessageForDescription = driver.findElement(entityDetails.getErrorMessageForMissingDescriptionForPresentationCategory).getText();
        String errorMessageForLongName = driver.findElement(entityDetails.getErrorMessageForMissingLongNameForPresentationCategory).getText();
        Assert.assertTrue(errorMessageForDescription.contains("Names - '"+createdEntityId+"' must have a 'English - United States' 'Description' in some period to cover Entity's lifecycle"));
        Assert.assertTrue(errorMessageForLongName.contains("Names - '"+createdEntityId+"' must have a 'English - United States' 'LongName' in some period to cover Entity's lifecycle"));

        driver.switchTo().window(Util.switchToSecondWindow(driver));
        String jobId = driver.findElement(entityDetails.getJobId).getAttribute("value");
        driver.switchTo().window(Util.switchToWindow(driver));
        Util.waitUntil(driver,homePage.jobManagement);
        driver.findElement(homePage.jobManagement).click();
        Util.waitUntil(driver, entityDetails.existingJobSearchButton);
        driver.findElement(entityDetails.enterJobIdInJobManagementPage).sendKeys(jobId);
        driver.findElement(entityDetails.existingJobSearchButton).click();
        Util.waitUntil(driver,entityDetails.existingJobSearchButton);
        String processingState = driver.findElement(entityDetails.processingStateOfTheSearchedJobId).getText();
        Assert.assertTrue(processingState.equalsIgnoreCase("Draft"));


    }

    @Test(groups = {"addNewObjectTypeMappingForPresentationCategoryWithAtSignFormulaName", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addNewObjectTypeMappingForPresentationCategoryWithAtSignFormulaName(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        uiUtils.addNewObjectTypeMappingForEntity(driver,testData);

        driver.findElement(homePage.home).click();
        Util.waitUntil(driver,homePage.home);

        driver.findElement(homePage.presentationCategory).click();

        DIRBean testDataFromPresentationCategoryCreation =    presentationCategoryUtils.createPresentationCategoryEntity(testObject,testData,driver);
        Util.sleep(25);
        String actual_RdfDataFromDB = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Assert.assertTrue(actual_RdfDataFromDB.contains("description"));


       /* String graphUri = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Assert.assertTrue(actual_MockupServiceResponse.contains("description"));*/
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

    }

    @Test(groups = {"addNewObjectTypeMappingForPresentationCategoryWithDollarSignFormulaName", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addNewObjectTypeMappingForPresentationCategoryWithDollarSignFormulaName(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        uiUtils.addNewObjectTypeMappingForEntity(driver,testData);

        driver.findElement(homePage.home).click();
        Util.waitUntil(driver,homePage.home);

        driver.findElement(homePage.presentationCategory).click();

        DIRBean testDataFromPresentationCategoryCreation =    presentationCategoryUtils.createPresentationCategoryEntity(testObject,testData,driver);
        Util.sleep(25);
        System.out.println(testData.getEntityId());
        String actual_RdfDataFromDB = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);

       // Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromRegisteredDataTypeCreation.getEntityId()));
        Assert.assertTrue(actual_RdfDataFromDB.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Assert.assertTrue(actual_RdfDataFromDB.contains("hasPermID"));


     /*   String graphUri = util.getDbData(testDataFromPresentationCategoryCreation.getEntityId(), "GRAPH_URI");
        logger.info("GraphURI from DB: " + graphUri);

        String actual_MockupServiceResponse = util.getMetadataFromMockupService(graphUri.replace("ecp:", ""));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getEntityId()));
        Assert.assertTrue(actual_MockupServiceResponse.contains(testDataFromPresentationCategoryCreation.getUniqueName()));
        Assert.assertTrue(actual_MockupServiceResponse.contains("hasPermID"));*/
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }
}
