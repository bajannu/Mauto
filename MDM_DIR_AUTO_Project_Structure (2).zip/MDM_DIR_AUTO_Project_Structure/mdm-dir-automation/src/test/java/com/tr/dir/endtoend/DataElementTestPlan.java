
package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.DataElementUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class DataElementTestPlan extends UiUtils {

    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-DataElement.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    DataElementUtil deUtil = new DataElementUtil();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(DataElementTestPlan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(DataElementTestPlan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"validateMappingForDataElement", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validateMappingForDataElement(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        driver.findElement(homePage.objectTypeMapping).click();
        Assert.assertTrue(uiUtils.getAllObjectTypes(driver).contains(testData.getEntity()), "DataElement is not added on ObjectType mapping!!");

    }

    @Test(groups = {"createDataElementEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createDataElementEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElement);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        //Util.setProperty("DATA_ELEMENT_ENTITY_ID", createdEntityId);
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        deUtil.fillDataElementEntityDetails(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(15);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        deUtil.validateDataElement(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"modifyDataElement", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyDataElement(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElement);
        createdEntityId = driver.findElement(entityDetails.selectEntity).getText();
        clickElement(driver, entityDetails.selectEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        driver.findElement(entityDetails.jobName2).sendKeys(uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));
        enterText(driver, entityDetails.sourceNote, testData.getSourceNote());
        enterText(driver, entityDetails.comments, testData.getComments());
        clickElement(driver, entityDetails.isNullable);
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        deUtil.validateDataElement(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"createDataElementWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createDataElementWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.dataElement);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        deUtil.fillDataElementEntityDetails(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);
        Util.sleep(DEFAULT_WAIT_TIME);
        String errorMessage = getText(driver, entityDetails.dataElementErrorMessage);
        Assert.assertEquals(errorMessage, "Namespace field is required", "Not showing error message!!");

    }

    //@Test(groups = {"addRecordInDataElementRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addRecordInDataElementRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.dataElementObjectType);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        clickElement(driver, homePage.home);
        clickElement(driver, homePage.dataElement);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        deUtil.fillDataElementEntityDetails(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        deUtil.validateDataElement(createdEntityId, actual_RdfDataFromDB, testData);

        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        ArrayList<String> objectTypeMappingList =  util.getObjectTypeMappingDB(testData);
        deUtil.validateDBObjectTypeMapping(objectTypeMappingList,actual_RdfDataFromDB);
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }

}

