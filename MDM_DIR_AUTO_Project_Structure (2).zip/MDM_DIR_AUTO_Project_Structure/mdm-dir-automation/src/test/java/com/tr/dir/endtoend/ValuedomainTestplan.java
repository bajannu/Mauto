package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.ValueDomainUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class ValuedomainTestplan extends UiUtils {


    final static String DATAPROVIDER_NAME = "ECP";
    final static String  CSV_PATH="./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-ValueDomain.csv";
    WebDriver driver=null;
    HomePage homePage=new HomePage();
    UiUtils uiUtils=new UiUtils();
    Util util = new Util();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    ValueDomainUtil valueDomainUtils = new ValueDomainUtil();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    String createdEntityId = "";
    String createdEntityIdWOMF= "";
    public static final Logger logger = LoggerFactory.getLogger(ValuedomainTestplan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(ValuedomainTestplan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }


    @Test(groups = {"validateMappingForValueDomain", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validateMappingForValueDomain(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        driver.findElement(homePage.objectTypeMapping).click();
        System.out.println(testData.getEntity());
        Assert.assertTrue(uiUtils.getAllObjectTypes(driver).contains(testData.getEntity()), "ValueDomain is not added on ObjectType mapping!!");

    }


    @Test(groups = {"createValueDomainEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createValueDomainEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.valueDomain).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);

        valueDomainUtils.fillValueDomainEntityDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(DEFAULT_WAIT_TIME);
        Util.sleep(DEFAULT_WAIT_TIME);
        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        valueDomainUtils.validateValueDomainMapping(createdEntityId,actual_RdfDataFromDB,testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

    }

    @Test(groups = {"createValueDomainModifyValueDomainEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createValueDomainModifyValueDomainEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        String sourceNoteModifyValue = String.valueOf(System.currentTimeMillis());
        driver.findElement(homePage.valueDomain).click();
        driver.findElement(entityDetails.generalEntitySearch).sendKeys(createdEntityId);
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.findElement(entityDetails.search).click();
        driver.findElement(entityDetails.valueDomainSelectResult).click();
        Util.sleep(DEFAULT_WAIT_TIME);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        driver.findElement(entityDetails.jobName2).sendKeys(uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));

        driver.findElement(entityDetails.relTypeSourceNote).sendKeys(sourceNoteModifyValue);

        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(DEFAULT_WAIT_TIME);
        Util.sleep(DEFAULT_WAIT_TIME);
        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        valueDomainUtils.validateValueDomainModifiedMapping(createdEntityId,actual_RdfDataFromDB,testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"createValuedomainWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createValuedomainWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        driver.findElement(homePage.valueDomain).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityIdWOMF = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityIdWOMF, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityIdWOMF);

        valueDomainUtils.fillValueDomainEntityWithoutFields(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        String errorMessage = driver.findElement(entityDetails.valueDomainerrorMessage).getText();
        Assert.assertTrue(errorMessage.contains("must have a 'English - United States' 'Description' "), "Not showing error message if we don't provide mandatory details while creating entity!!");
        driver.close();
    }



    //@Test(groups = {"addRecordInValueDomainRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addRecordInValueDomainRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.valueDomainObjectType);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        clickElement(driver, homePage.home);
        driver.findElement(homePage.valueDomain).click();
        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);

        valueDomainUtils.fillValueDomainEntityDetails(driver, uniqueJobName, testData);
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(DEFAULT_WAIT_TIME);
        Util.sleep(DEFAULT_WAIT_TIME);
        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        logger.info("RDF Data from DB: " + actual_RdfDataFromDB);
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        valueDomainUtils.validateValueDomainModifiedMapping(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        ArrayList<String> objectTypeMappingList =  util.getObjectTypeMappingDB(testData);
        valueDomainUtils.validateDBObjectTypeMapping(objectTypeMappingList,actual_RdfDataFromDB);
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }
}
