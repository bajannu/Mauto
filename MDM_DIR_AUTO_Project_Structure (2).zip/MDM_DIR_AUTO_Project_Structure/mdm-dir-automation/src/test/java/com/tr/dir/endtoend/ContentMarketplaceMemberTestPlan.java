package com.tr.dir.endtoend;

import com.tm.ecp.base.common.util.TMCsvUtil;
import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import com.tr.dir.utils.entityUtils.ContentMarketplaceUtil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class ContentMarketplaceMemberTestPlan extends UiUtils {
    final static String DATAPROVIDER_NAME = "ECP";
    final static String CSV_PATH = "./src/test/java/com/tr/dir/endtoend/testdata/EcpTestData-ContentMarketplaceMember.csv";
    WebDriver driver = null;
    HomePage homePage = new HomePage();
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    EntityDetailsPage entityDetails = new EntityDetailsPage();
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    ContentMarketplaceUtil cmpUtil = new ContentMarketplaceUtil();
    String createdEntityId = "";
    public static final Logger logger = LoggerFactory.getLogger(ValuedomainTestplan.class);

    @DataProvider(name = DATAPROVIDER_NAME)
    public static Iterator<Object[]> getCandidateInfo(Method method) {
        Iterator<Object[]> objectsFromCsv = null;
        try {
            LinkedHashMap<String, Class<?>> entityClazzMap = new LinkedHashMap<String, Class<?>>();
            LinkedHashMap<String, String> methodFilter = new LinkedHashMap<String, String>();
            methodFilter.put(TestObject.TEST_TITLE, method.getName());
            entityClazzMap.put("TestObject", TestObject.class);
            entityClazzMap.put("DIRBean", DIRBean.class);
            objectsFromCsv = TMCsvUtil.getObjectsFromCsv(ValuedomainTestplan.class, entityClazzMap, CSV_PATH, null,
                    methodFilter);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return objectsFromCsv;
    }

    @Test(groups = {"validateMappingForContentMarketplace", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void validateMappingForContentMarketplace(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        driver.findElement(homePage.objectTypeMapping).click();
        Assert.assertTrue(uiUtils.getAllObjectTypes(driver).contains(testData.getEntity()), "ContentMarketplace is not added on ObjectType mapping!!");

    }

    @Test(groups = {"createContentMarketplaceMemberEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentMarketplaceMemberEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentMarketplaceMember);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Util.setProperty("CONTENT_MARKETPLACE_ENTITYID", createdEntityId, "cmp");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        cmpUtil.fillContentMarketplaceDetails(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(15);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        System.out.println("actual_RdfDataFromDB: " + actual_RdfDataFromDB);
        cmpUtil.validateContentMarketplaceData(createdEntityId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

    }

    @Test(groups = {"modifyContentMarketplaceMemberEntity", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void modifyContentMarketplaceMemberEntity(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentMarketplaceMember);

        String existingContentMarketplaceId = Util.getProperty("CONTENT_MARKETPLACE_ENTITY_ID");
        enterText(driver, entityDetails.searchEntityId, existingContentMarketplaceId);
        clickElement(driver, entityDetails.entitySearchButton);
        clickElement(driver, entityDetails.selectEntity);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        clickElement(driver, entityDetails.editEntity);
        driver.switchTo().window(Util.switchToNewWindow(driver));

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        enterText(driver, entityDetails.jobName2, uniqueJobName);
        clickElement(driver, entityDetails.next2);
        driver.switchTo().window(Util.switchToSecondWindow(driver));
        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        enterText(driver, entityDetails.sourceNote, testData.getSourceNote());
        enterText(driver, entityDetails.comments, testData.getComments());

        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        String actual_RdfDataFromDB = util.getDbData(existingContentMarketplaceId, "RDF");
        Assert.assertNotNull(actual_RdfDataFromDB, "Not generating RDF data in DB !!");
        cmpUtil.validateContentMarketplaceData(existingContentMarketplaceId, actual_RdfDataFromDB, testData);
        Util.rdfValidationwithOntology(actual_RdfDataFromDB);
    }

    @Test(groups = {"createContentMarketplaceMemberWithoutMandatoryFields", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void createContentMarketplaceMemberWithoutMandatoryFields(TestObject testObject, DIRBean testData) {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));

        clickElement(driver, homePage.contentMarketplaceMember);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        entityDetails.sendToJob(driver);
        Assert.assertEquals(getText(driver, entityDetails.cmpErrorMessage), "Namespace field is required", "Not throwing error message for mandatory fields !!");

    }

    //@Test(groups = {"addRecordInContentMarketplaceRdfMapping", "EndToEndTests"}, dataProvider = DATAPROVIDER_NAME)
    public void addRecordInContentMarketplaceRdfMapping(TestObject testObject, DIRBean testData) throws IOException {

        driver = login(this.driver, System.getProperty("user"), System.getProperty("password"));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.objectMapping);
        clickElement(driver, objectMapping.objectType);
        clickElement(driver, objectMapping.contentMarketplaceMember);
        clickElement(driver, objectMapping.addObjectMapping);

        uiUtils.modifyRDFMappingDetails(driver, testData);

        clickElement(driver, homePage.home);
        clickElement(driver, homePage.contentMarketplaceMember);
        clickElement(driver, entityDetails.addNewEntity);

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        entityDetails.createNewJob(driver, uniqueJobName);

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        System.out.println("createdEntityId: " + createdEntityId);
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        cmpUtil.fillContentMarketplaceDetails(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        entityDetails.sendToJob(driver);
        entityDetails.validateAndApprovrJob(driver);

        Util.sleep(20);

        String actual_RdfDataFromDB = util.getDbData(createdEntityId, "RDF");
        System.out.println("actual_RdfDataFromDB: " + actual_RdfDataFromDB);
        cmpUtil.validateContentMarketplaceData(createdEntityId, actual_RdfDataFromDB, testData);

        Util.rdfValidationwithOntology(actual_RdfDataFromDB);

        ArrayList<String> objectTypeMappingList = util.getObjectTypeMappingDB(testData);
        cmpUtil.validateDBObjectTypeMapping(objectTypeMappingList, actual_RdfDataFromDB);
    }

    public void tearDown() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    @AfterMethod(alwaysRun = true)
    public void afterTestMethod(Method method) {
        tearDown();
    }

    @AfterSuite(alwaysRun = true)
    public void afterTestSuite() {
        tearDown();
    }


}
