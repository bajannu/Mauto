package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.sql.*;

public class IdentifierUtil {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));

    private String dbHost = Util.getProperty("DB_HOST");
    private String dbServiceName = Util.getProperty("SERVICE_NAME");
    private String dbUserName = Util.getProperty("DB_USER");
    private String dbPassword = Util.getProperty("DB_PASSWORD");
    public static final Logger logger = LoggerFactory.getLogger(Util.class);



    public void fillIdentifierEntityDetails(WebDriver driver, String uniqueJobName, DIRBean testData) throws InterruptedException {

        fillIdentifierDetails(driver, uniqueJobName, testData);
    }

    public void fillIdentifierDetails(WebDriver driver, String uniqueJobName, DIRBean testData) throws InterruptedException {

        String identifierValue = String.valueOf(System.currentTimeMillis());
        Util.selectIdentifierType(driver, driver.findElement(entityDetails.identifierTypedropdown), testData.getNamespace());
        Util.selectIdentifierObjectType(driver, driver.findElement(entityDetails.identifierobjectType), testData.getNamespace());
        driver.findElement(entityDetails.selectObjectID).click();
        driver.findElement(entityDetails.objectIDSearchCss).click();
        Util.sleep(DEFAULT_WAIT_TIME);

        driver.switchTo().window(Util.switchToThirdWindow(driver));

        Util.waitUntil(driver, entityDetails.objectSearch);
        driver.findElement(entityDetails.objectSearch).click();

        Util.waitUntil(driver, entityDetails.objectListSelect1);
        driver.findElement(entityDetails.objectListSelect1).click();
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.switchTo().window(Util.switchToNewWindow(driver));
        driver.findElement(entityDetails.identifierIDValue).click();
        driver.findElement(entityDetails.identifierIDValue).sendKeys(identifierValue);
    }


    public void fillPartialIdentifierEntityDetails(WebDriver driver, String uniqueJobName, DIRBean testData) throws InterruptedException {

        fillpartialIdentifierDetails(driver, uniqueJobName, testData);
    }

    public void fillpartialIdentifierDetails(WebDriver driver, String uniqueJobName, DIRBean testData) throws InterruptedException {

        Util.selectIdentifierType(driver, driver.findElement(entityDetails.identifierTypedropdown), testData.getNamespace());
        Util.selectIdentifierObjectType(driver, driver.findElement(entityDetails.identifierobjectType), testData.getNamespace());
        driver.findElement(entityDetails.selectObjectID).click();
        driver.findElement(entityDetails.objectIDSearchCss).click();
        Util.sleep(DEFAULT_WAIT_TIME);

        driver.switchTo().window(Util.switchToThirdWindow(driver));

        Util.waitUntil(driver, entityDetails.objectSearch);
        driver.findElement(entityDetails.objectSearch).click();

        Util.waitUntil(driver, entityDetails.objectListSelect1);
        driver.findElement(entityDetails.objectListSelect1).click();
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.switchTo().window(Util.switchToNewWindow(driver));


    }
    public String getIdentifierIDDB(String entityId, String columnName)  {

        String graphUri = null;
        Connection connection = null;

        try {
            Driver orcleDriver = new oracle.jdbc.driver.OracleDriver();
            DriverManager.registerDriver(orcleDriver);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@" + dbHost + "/" + dbServiceName + "", dbUserName, dbPassword);

            Statement stmt = connection.createStatement();
            String sql = "SELECT * FROM MDM.IDENTIFIERS WHERE IDENTIFIER_ID=" + entityId;

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                graphUri = rs.getString(columnName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return graphUri;

    }

    public static void validateDataElement(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("<ecp:srcNote>"));
        Assert.assertTrue(actualData.contains("isCalculable> \"false\""));
        Assert.assertTrue(actualData.contains("hasContentPublishingService"));
        Assert.assertTrue(actualData.contains("hasCurrency> \"false\""));
        Assert.assertTrue(actualData.contains("hasLanguage> \"false\""));
        Assert.assertTrue(actualData.contains("hasScale> \"false\""));
        Assert.assertTrue(actualData.contains("isNullable> \"false\""));
        Assert.assertTrue(actualData.contains("hasNamespace>"));

    }
}
