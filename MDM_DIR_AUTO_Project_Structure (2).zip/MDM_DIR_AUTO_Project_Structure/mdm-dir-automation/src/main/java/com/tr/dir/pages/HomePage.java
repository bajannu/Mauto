package com.tr.dir.pages;

import org.openqa.selenium.By;

public class HomePage {

    public By home = By.id("ctl00_MenuBarCtrl1_linkHome");
    public By jobManagement = By.id("ctl00_MenuBarCtrl1_linkJobManagement");
    public By jobReport = By.id("ctl00_MenuBarCtrl1_linkJobSummary");
    public By qualityReport = By.id("ctl00_MenuBarCtrl1_linkQualityReport");
    public By relationshipEditor = By.id("ctl00_MenuBarCtrl1_linkTreeViewRelEditor");
    public By contentItemEditor = By.id("ctl00_MenuBarCtrl1_linkTreeViewSchemaGenerating");
    public By sqlRunner = By.id("ctl00_MenuBarCtrl1_linkSqlRunner");
    public By logViewer = By.id("ctl00_MenuBarCtrl1_linkLogFileViewer");
    public By rdfMapping = By.id("ctl00_MenuBarCtrl1_linkRDFObjectMapping");
    public By ecpServiceMapping = By.id("ctl00_MenuBarCtrl1_linkECPServiceMapping");
    public By ecpServiceRegistration = By.id("ctl00_MenuBarCtrl1_linkECPServiceRegistration");
    public By objectTypeMapping = By.id("ctl00_MenuBarCtrl1_linkObjectTypeMapping");
    public By objectMapping = By.id("ctl00_MenuBarCtrl1_linkObjectMapping");
    public By rdfLookup = By.id("ctl00_MenuBarCtrl1_linkRDFLookup");
    public By contentMarketplaceMember = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl01_BigList");
    public By contentPublishingService = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl02_BigList");
    public By contentItemPublication = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl03_BigList");
    public By contentItem = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl04_BigList");
    public By dataElement = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl05_BigList");
    public By dataElementKey = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl06_BigList");
    public By valueDomain = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl08_SmallList");
    public By valueDomainEnumeration = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl07_SmallList");
    public By namespace = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl09_LargeButtonList");
    public By presentationCategory = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl10_BigList");
    public By registeredDataType = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl11_BigList");
    public By identifierType = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl13_SmallList");
    public By identifier = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl12_SmallList");
    public By relationshipType = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl15_SmallList");
    public By relationship = By.id("ctl00_cpM_DirListCtrl_rpDirList_ctl14_SmallList");
}


