package com.tr.dir.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    public By userId = By.id("ctl00_cpM_txtUserID");
    public By password = By.id("ctl00_cpM_txtPassword");
    public By login = By.id("ctl00_cpM_btnLogin");
    public By home = By.id("ctl00_MenuBarCtrl1_linkHome");

}



