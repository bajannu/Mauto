package com.tr.dir.utils;

import com.google.gson.Gson;
import com.tm.ecp.base.utils.bean.LoginRequest;
import com.tm.ecp.base.utils.bean.LoginResponse;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import javax.ws.rs.client.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

/**
 * Created by Santosh Chandrakant on 20/04/2018.
 */
public class RestUtil {

    enum RequestMethod {
        GET, POST, PUT, DELETE
    }

    static Gson gson = new Gson();

    /**
     *
     * @param url
     * @param requestMethod [GET or POST or PUT or DELETE]
     * @param headers
     * @param requestBody
     * @param mediaType
     * @return responseObject
     */
    public static Response hitAPI(String url, RequestMethod requestMethod, MultivaluedMap<String, Object> headers, Object requestBody, MediaType mediaType) {

        Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
        WebTarget webTarget = client.target(url);
        Invocation.Builder invocationBuilder = null;

        if (headers == null) {
            invocationBuilder = webTarget.request(mediaType);
        } else {
            invocationBuilder = webTarget.request(mediaType).headers(headers);
        }
        Response response = null;
        if (requestMethod.toString().equals("GET")) {
            response = invocationBuilder.get();
        }
        if (requestMethod.toString().equals("POST")) {
            response = invocationBuilder.post(Entity.entity(requestBody, MediaType.APPLICATION_JSON));
        }
        if (requestMethod.toString().equals("PUT")) {
            response = invocationBuilder.put(Entity.entity(requestBody, MediaType.APPLICATION_JSON));
        }
        if (requestMethod.toString().equals("DELETE")) {
            response = invocationBuilder.delete();
        }
        return response;
    }

    /**
     * Get Access Token
     *
     * @param url
     * @param userName
     * @param password
     * @return accessToken
     */
    public static String getToken(String url, String userName, String password) {
        LoginRequest requestBody = new LoginRequest();
        requestBody.setUsername(userName);
        requestBody.setPassword(password);
        return gson.fromJson(RestUtil.hitAPI(url, RequestMethod.POST, null, requestBody, MediaType.APPLICATION_JSON_TYPE).readEntity(String.class), LoginResponse.class).getAccessToken();
    }
}
