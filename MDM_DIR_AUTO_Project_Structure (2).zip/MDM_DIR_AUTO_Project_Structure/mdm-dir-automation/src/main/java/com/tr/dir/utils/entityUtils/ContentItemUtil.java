package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.ArrayList;

public class ContentItemUtil extends UiUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));

    /**
     * Fill ContentItem entity details
     *
     * @param driver
     * @param uniqueJobName
     * @param testData
     */
    public void fillContentItemEntityDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {

        fillContentItemDetails(driver, uniqueJobName, testData);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(DEFAULT_WAIT_TIME);
        clickElement(driver, entityDetails.selectNameType);
        if (testData.getNametype1().equals("LongName")) {
            addLongName(driver, testData);
        }
        Util.sleep(DEFAULT_WAIT_TIME);
        if (testData.getNametype2().equals("Description")) {
            clickElement(driver, entityDetails.addNameType);
            driver.switchTo().window(Util.switchToNewWindow(driver));
            Util.waitUntil(driver, entityDetails.selectNameType);
            Util.sleep(DEFAULT_WAIT_TIME);
            addDescription(driver, testData);
        }

    }

    public void fillContentItemDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        if (uniqueJobName != null) {
            enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        }
        if (testData.getContentPublishingService() != null) {
            Util.selectContentPublishingService(driver, driver.findElement(entityDetails.contentPublishingService), testData.getContentPublishingService());
        }
        if (testData.getNamespace() != null) {
            Util.selectNamespace(driver, driver.findElement(entityDetails.namespace), testData.getNamespace());
        }
        if (testData.getMajorVersion() != null) {
            enterText(driver, entityDetails.majorVersion, testData.getMajorVersion());
        }
        if (testData.getMinorVersion() != null) {
            enterText(driver, entityDetails.minorVersion, testData.getMinorVersion());
        }
        if (testData.getRevisionVersion() != null) {
            driver.findElement(entityDetails.revisionVersion).sendKeys(testData.getRevisionVersion());
        }
        if (testData.getSourceNote() != null) {
            enterText(driver, entityDetails.sourceNote, testData.getSourceNote());
        }
        if (testData.getComments() != null) {
            enterText(driver, entityDetails.comments, testData.getComments());
        }
        if (testData.getXmlNamespace() != null) {
            enterText(driver, entityDetails.xmlNamespace, testData.getXmlNamespace());
        }
        if (testData.getXmlSchema() != null) {
            enterText(driver, entityDetails.xmlSchema, testData.getXmlSchema());
        }
        clickElement(driver, entityDetails.objectNames);
        clickElement(driver, entityDetails.addNameType);
    }

    /**
     * Click ContentItem from HomePage and Create ContentItem
     *
     * @param driver
     * @param testData
     * @return entityID
     */
    public String createContentItem(WebDriver driver, DIRBean testData) {

        driver.findElement(homePage.contentItem).click();
        driver.findElement(entityDetails.addNewEntity).click();
        driver.findElement(entityDetails.existingJobCheckbox).click();
        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectAJob);

        driver.findElement(entityDetails.selectAJob).click();
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.switchTo().window(Util.switchToSecondWindow(driver));

        Util.waitUntil(driver, entityDetails.entityID2);
        String createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        fillContentItemDetails(driver, uniqueJobName, testData);
        addNameTypes(driver, uniqueJobName, testData);

        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);

        mapCreatedEntityToService(driver, createdEntityId);
        return createdEntityId;
    }

    public void addNameTypes(WebDriver driver, String uniqueJobName, DIRBean testData) {
        driver.switchTo().window(Util.switchToSecondWindow(driver));
        Util.sleep(DEFAULT_WAIT_TIME);
        Util.waitUntil(driver, entityDetails.selectNameType);
        driver.findElement(entityDetails.selectNameType).click();
        if (testData.getNametype1().equals("LongName")) {
            addLongName(driver, testData);
        }
        Util.sleep(DEFAULT_WAIT_TIME);
        if (testData.getNametype2().equals("Description")) {
            clickElement(driver, entityDetails.addNameType);
            driver.switchTo().window(Util.switchToSecondWindow(driver));
            Util.waitUntil(driver, entityDetails.selectNameType);
            Util.sleep(DEFAULT_WAIT_TIME);
            addDescription(driver, testData);
        }
    }

    public void mapCreatedEntityToService(WebDriver driver, String createdEntityId) {
        driver.switchTo().window(Util.switchToWindow(driver));
        clickElement(driver, homePage.home);
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();

        clickElement(driver, homePage.ecpServiceMapping);
        Util.waitUntil(driver, entityDetails.serviceName);
        clickElement(driver, entityDetails.serviceName);
        clickElement(driver, entityDetails.addContentItem);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        enterText(driver, entityDetails.searchEntityId, createdEntityId);
        clickElement(driver, entityDetails.entitySearchButton);
        Util.sleep(DEFAULT_WAIT_TIME);
        clickElement(driver, entityDetails.entityCheckBox);
        clickElement(driver, entityDetails.mapSelectedItems);
    }

    /**
     * Validate data
     *
     * @param createdEntityId
     * @param actualData
     * @param testData
     */
    public static void validateContentItem(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains(testData.getMajorVersion()));
        Assert.assertTrue(actualData.contains(testData.getMinorVersion()));
        Assert.assertTrue(actualData.contains(testData.getRevisionVersion()));
        //Assert.assertTrue(actualData.contains(testData.getXmlNamespace()));
        Assert.assertTrue(actualData.contains(testData.getXmlSchema()));
        //ContentPublishingService
        //MajorVersion
        //SourceNote
        //Comments
    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }

}
