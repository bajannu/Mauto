package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;

public class ContentItemPublicationUtil extends UiUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));

    public void fillContentItemPublicationDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {

        driver.switchTo().window(Util.switchToNewWindow(driver));
        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        if (testData.getName1() != null) {
            enterText(driver, entityDetails.cipName, testData.getName1());
        }
        enterText(driver, entityDetails.cipCIId, Util.getProperty("CONTENT_ITEM_ENTITY_ID"));
        enterText(driver, entityDetails.cipPublishingServiceId, Util.getProperty("CONTENT_PUBLISHING_SERVICE_ENTITY_ID"));
        selectStyle(driver);
        selectFrequency(driver);
        selectPartitionType(driver);
        selectPartition(driver);

    }

    public void selectStyle(WebDriver driver) {
        clickElement(driver, entityDetails.style);
        clickElement(driver, entityDetails.styleValue);
    }

    public void selectFrequency(WebDriver driver) {
        clickElement(driver, entityDetails.cipFrequency);
        clickElement(driver, entityDetails.cipFrequencyValue);
    }

    public void selectPartitionType(WebDriver driver) {
        clickElement(driver, entityDetails.cipPartitionType);
        clickElement(driver, entityDetails.cipPartitionTypeValue);
    }

    public void selectPartition(WebDriver driver) {
        clickElement(driver, entityDetails.cipPartition);
        clickElement(driver, entityDetails.cipPartitionValue);
    }
}
