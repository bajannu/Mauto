package com.tr.dir.utils;

import com.hp.hpl.jena.rdf.model.Model;
import com.tr.dir.bean.DIRBean;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.xpath.operations.Bool;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import javax.ws.rs.core.Response;
import java.io.*;

import java.sql.*;
import java.util.*;

import com.tr.ecp.RDFutil;


public class Util {

    private static String dbHost = Util.getProperty("DB_HOST");
    private static String dbServiceName = Util.getProperty("SERVICE_NAME");
    private static String dbUserName = Util.getProperty("DB_USER");
    private static String dbPassword = Util.getProperty("DB_PASSWORD");
    private String mockup_service_host = Util.getProperty("MOCKUP_SERVICE_HOST");
    public static final Logger logger = LoggerFactory.getLogger(Util.class);

    /**
     * Get property value from properties file
     *
     * @param key
     * @return property value
     */
    public static String getProperty(String key) {
        String value = null;
        Properties properties = new Properties();
        String environment = System.getProperty("environment");
        if (environment == null)
            environment = "qa";
        File file = new File("resources/" + environment + "-config.properties");
        try {
            FileInputStream fileInput = new FileInputStream(file);
            properties.load(fileInput);
            value = properties.getProperty(key);

        } catch (Exception e) {
            System.out.println("Failed to get property !!");
        }
        return value;

    }

    /**
     * Get property value from properties file
     *
     * @param key
     * @return property value
     */
    public static String getPropertyEntity(String key, String fileName) {
        String value = null;
        Properties properties = new Properties();
        File file = new File("resources/" + fileName + ".properties");
        try {
            FileInputStream fileInput = new FileInputStream(file);
            properties.load(fileInput);
            value = properties.getProperty(key);

        } catch (Exception e) {
            System.out.println("Failed to get property !!");
        }
        return value;

    }

    /**
     * Set property value to properties file
     *
     * @param key
     * @param value
     */
    public static void setProperty(String key, String value, String file) {

        Properties props = new Properties();
        try {
            FileOutputStream out = new FileOutputStream("resources/" + file + ".properties");
            props.setProperty(key, value);
            props.store(out, null);
            out.close();
        } catch (Exception e) {

        }

    }

    /**
     * Get data from DB
     *
     * @param entityId
     * @param columnName
     * @return columnDataFromDB
     */
    public String getDbData(String entityId, String columnName) {

        String graphUri = null;
        Connection connection = null;

        try {
            Driver orcleDriver = new oracle.jdbc.driver.OracleDriver();
            DriverManager.registerDriver(orcleDriver);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@" + dbHost + "/" + dbServiceName + "", dbUserName, dbPassword);

            Statement stmt = connection.createStatement();
            String sql = "SELECT * FROM MDM.RDF_RESULT WHERE OBJECT_ID=" + entityId;
            System.out.println("Query for rdf result: " + sql);
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                graphUri = rs.getString(columnName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("Response from DB: " + graphUri);
        return graphUri;

    }

    public ArrayList<String> getObjectTypeMappingDB(DIRBean testData) {
        String result = null;
        Connection connection = null;
        String columnName = "PROPERTY_NAME";

        ArrayList<String> resultList = null;
        try {
            Driver orcleDriver = new oracle.jdbc.driver.OracleDriver();
            DriverManager.registerDriver(orcleDriver);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@" + dbHost + "/" + dbServiceName + "", dbUserName, dbPassword);

            Statement stmt = connection.createStatement();
            String sql = "SELECT MDM.RDF_OBJECT_MAPPING.PROPERTY_NAME, MDM.RDF_OBJECT_MAPPING.RDF_URI FROM MDM.RDF_OBJECT_MAPPING INNER JOIN IFE.ENTITIES ON MDM.RDF_OBJECT_MAPPING.OBJECT_ID = IFE.ENTITIES.ENTITYTYPE WHERE IFE.ENTITIES.ENTITY = '" + testData.getEntity() + "' AND MDM.RDF_OBJECT_MAPPING.INCLUDE_IN_RESULT = 1";
            System.out.println("sql: " + sql);

            ResultSet rs = stmt.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            resultList = new ArrayList<>(columnCount);

            while (rs.next()) {
                resultList.add(rs.getString(columnName));
                //result = rs.getString(columnName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return resultList;
    }

    public String isEntityIdExistsInDB(String tableName, String entityId, String columnName) {
        String result = null;
        Connection connection = null;

        try {
            Driver orcleDriver = new oracle.jdbc.driver.OracleDriver();
            DriverManager.registerDriver(orcleDriver);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@" + dbHost + "/" + dbServiceName + "", dbUserName, dbPassword);

            Statement stmt = connection.createStatement();
            String sql = "SELECT * FROM MDM." + tableName + " WHERE " + columnName + " =" + entityId;
            System.out.println("sql: " + sql);

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                result = rs.getString(columnName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return result;
    }

    /**
     * Get metadata using MockupService
     *
     * @param ecpId
     * @return responseBody
     */
    public String getMetadataFromMockupService(String ecpId) {
        String url = "http://" + mockup_service_host + "/RegistryMockService/FileTransferService.svc/GetFile?fileName=" + ecpId + ".json";
        logger.info("MockupService URL: " + url);
        Response response = RestUtil.hitAPI(url, RestUtil.RequestMethod.GET, null, null, null);
        logger.info("Response code : " + response.getStatus());
        Assert.assertEquals(200, response.getStatus());
        String responseBody = response.readEntity(String.class);
        logger.info("MockupService Response: " + responseBody);
        return responseBody;
    }

    public static String switchToSecondWindow(WebDriver driver) {
        Set<String> wid = driver.getWindowHandles();
        Iterator<String> itr = wid.iterator();
        String pid = itr.next();
        String wid2 = itr.next();
        return itr.next();
    }

    public static String switchToThirdWindow(WebDriver driver) {
        Set<String> wid = driver.getWindowHandles();
        Iterator<String> itr = wid.iterator();
        String pid = itr.next();
        String wid2 = itr.next();
        String wid3 = itr.next();
        return itr.next();
    }

    public static String switchToFourthWindow(WebDriver driver) {
        Set<String> wid = driver.getWindowHandles();
        Iterator<String> itr = wid.iterator();
        String pid = itr.next();
        String wid2 = itr.next();
        String wid3 = itr.next();
        String wid4 = itr.next();
        return itr.next();
    }

    /**
     * Wait for seconds
     *
     * @param seconds
     */
    public static void sleep(int seconds) {
        try {
            Thread.sleep(1000 * seconds);
        } catch (Exception e) {

        }

    }

    /**
     * Wait until the given element is visible(Max 10seconds)
     *
     * @param driver
     * @param locator
     */
    public static void waitUntil(WebDriver driver, By locator) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        ExpectedConditions.visibilityOfElementLocated(locator);
        //ExpectedConditions.elementToBeClickable(locator);
    }

    /**
     * Switch to CreateNewJobPage
     *
     * @param driver
     * @return window
     */
    public static String switchToWindow(WebDriver driver) {
        Set<String> wid = driver.getWindowHandles();
        Iterator<String> itr = wid.iterator();
        return itr.next();
    }

    /**
     * Select dropdown by visible text
     *
     * @param driver
     * @param element
     * @param value
     */
    public static void selectContentPublishingService(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpCPS_drpBO']/option[3]")).click();
    }

    public static void selectRelationshipType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpRelType']/option[553]")).click();
    }

    public static void selectFromObjectType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpFromObjectType']/option[2]")).click();
    }

    public static void selectToObjectType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpToObjectType']/option[3]")).click();
    }

    public static void selectIdentifierType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpIDType']/option[8]")).click();
    }

    public static void selectIdentifierObjectType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpObjectType']/option[2]")).click();
    }

    public static void selectIdentifierObjectTypeOption3(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpIDType']/option[3]")).click();
    }

    public static void selectNamespace(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpNamespace_drpBO']/option[9]")).click();
    }

    public static void selectContentMartketPlaceMember(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpCMM_drpBO']/option[8]")).click();
    }

    public static String switchToNewWindow(WebDriver driver) {
        Set<String> wid = driver.getWindowHandles();
        Iterator<String> itr = wid.iterator();
        String pid = itr.next();
        return itr.next();
    }

    public static void selectValueDomain(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpVD_drpBO']/option[5]")).click();

    }

    public static void selectDataElementKey(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpDEKey_drpBO']/option[2]")).click();
    }

    public static void selectDataType(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpDataType_drpBO']/option[5]")).click();
    }

    public static void selectOwner(WebDriver driver, WebElement element, String value) {
        element.click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_eC_drpOwner_drpBO']/option[4]")).click();
    }


    public static void rdfValidationwithOntology(String rdfData) throws IOException {

        File inputRDFFile = new File("./src/test/resources/File1.nt");
        FileWriter fooWriter = new FileWriter(inputRDFFile, false); // true to append // false to overwrite.
        fooWriter.write(rdfData);
        fooWriter.close();
        File InputOntologyFile = new File("./src/test/resources/ecpontology.ttl");


        Model ontologyFile = RDFutil.resourceToModel(String.valueOf(InputOntologyFile));
        Model rdfFile = RDFutil.resourceToModel(String.valueOf(inputRDFFile));

        RDFutil.validatewithOntologyasString(ontologyFile, rdfFile);
    }

    public static void main(String[] args) {

        //Util.setProperty("CIP_QUERY", "sample");

    }

}