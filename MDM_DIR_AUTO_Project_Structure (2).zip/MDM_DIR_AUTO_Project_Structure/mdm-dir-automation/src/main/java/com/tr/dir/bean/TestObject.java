package com.tr.dir.bean;

import org.apache.commons.lang3.StringUtils;

public class TestObject {

    public static final String TEST_CASE_ID = "TestObject.TestCaseId";
    public static final String TEST_METHOD = "TestObject.TestMethod";
    public static final String TEST_TITLE = "TestObject.TestTitle";
    public static final String TEST_SITE = "TestObject.TestSite";
    public static final String TEST_DP_TAGS = "TestObject.TestTags";
    public static final String TEST_IS_ACTIVE = "TestObject.IsActive";
    private String testCaseId = "";
    private String testMethod = "";
    private String testTitle = "";
    private String testSite = "";
    private String testTags = "";
    private boolean isActive = true;
    private String testData;
    private String testSteps;

    public String getTestData() {
        return testData;
    }

    public void setTestData(String testData) {
        this.testData = testData;
    }

    public String getTestSteps() {
        return testSteps;
    }

    public void setTestSteps(String testSteps) {
        this.testSteps = testSteps;
    }



    public TestObject() {
    }

    public String getTestCaseId() {
        return this.testCaseId;
    }

    public String getTestMethod() {
        return this.testMethod;
    }

    public String getTestSite() {
        return this.testSite;
    }

    public String getTestTags() {
        return this.testTags;
    }

    public String getTestTitle() {
        return this.testTitle;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public void setTestCaseId(String testCaseId) {
        this.testCaseId = testCaseId;
    }

    public void setTestMethod(String testMethod) {
        this.testMethod = testMethod;
    }

    public void setTestSite(String testSite) {
        this.testSite = testSite;
    }

    public void setTestTags(String testTags) {
        this.testTags = testTags;
    }

    public void setTestTitle(String testTitle) {
        this.testTitle = testTitle;
    }

    public String toString() {
        StringBuffer ret = new StringBuffer();
        ret.append("[TestCaseId=" + this.testCaseId);
        if (StringUtils.isNotEmpty(this.testMethod)) {
            ret.append("|TestMethod=" + this.testMethod);
        }

        if (StringUtils.isNotEmpty(this.testTitle)) {
            ret.append("|TestTitle=" + this.testTitle);
        }

        if (StringUtils.isNotEmpty(this.testSite)) {
            ret.append("|Site=" + this.testSite);
        }

        if (StringUtils.isNotEmpty(this.testTags)) {
            ret.append("|DPTag=" + this.testTags);
        }

        if (!this.isActive) {
            ret.append("|IsActive=" + this.isActive);
        }

        ret.append("]");
        return ret.toString();
    }
}
