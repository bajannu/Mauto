package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.bean.TestObject;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.ArrayList;

public class RegisteredDataTypeUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    UiUtils uiUtils = new UiUtils();
    Util util = new Util();
    String createdEntityId = "";
    ObjectMappingPage objectMapping = new ObjectMappingPage();
    public static final Logger logger = LoggerFactory.getLogger(RegisteredDataTypeUtils.class);


    public DIRBean createRegisteredDataTypeEntity(TestObject testObject, DIRBean testData, WebDriver driver) {



        driver.findElement(entityDetails.addNewEntity).click();

        String uniqueJobName = "QED_Auto" + System.currentTimeMillis();
        testData.setUniqueName(uniqueJobName);

        if(testData.getJobType().equalsIgnoreCase("New"))
        {
            entityDetails.createNewJob(driver, uniqueJobName);
        }
        else if(testData.getJobType().equalsIgnoreCase("Existing"))
        {
            driver.findElement(entityDetails.existingJobCheckbox).click();
            Util.sleep(15);
            for (String winHandle : driver.getWindowHandles()) {
                driver.switchTo().window(winHandle);
            }
            // Util.waitUntil(driver,entityDetails.existingJobSearchButton);
            driver.findElement(entityDetails.selectAJob).click();
            driver.switchTo().window(Util.switchToSecondWindow(driver));
            Util.sleep(15);
        }

        createdEntityId = driver.findElement(entityDetails.entityID2).getAttribute("value");
        System.out.println("EntityID"+createdEntityId);
        Assert.assertNotNull(createdEntityId, "Not generating EntityId");
        logger.info("Created EntityId: " + createdEntityId);
        testData.setEntityId(createdEntityId);

        uiUtils.enterUniqueName(driver,testData);
        driver.findElement(entityDetails.descriptionTextBox).sendKeys(testData.getComments());

        entityDetails.sendToJob(driver);

        entityDetails.validateAndApprovrJob(driver);
        Util.sleep(25);
        return testData;

    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }

}
