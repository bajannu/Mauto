package com.tr.dir.bean;

public class DIRBean {

    private String contentPublishingService;
    private String namespace;
    private String majorVersion;
    private String minorVersion;
    private String sourceNote;
    private String revisionVersion;
    private String comments;
    private String xmlNamespace;
    private String xmlSchema;
    private String entity;
    private String nametype1;
    private String language1;
    private String name1;
    private String nametype2;
    private String language2;
    private String name2;
    private String valueDomain;
    private String dataElementKey;
    private String owner;
    private String datatype;
    private String relationshipType;
    private String objectType;
    private String identifierType;
    private String identifierValue;
    private String propertyName;
    private String formula;
    private String contentMarketPlaceMember;
    private String selectrelationship;
    private String selectObjectType;

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public String getContentMarketPlaceMember() {
        return contentMarketPlaceMember;
    }

    public void setContentMarketPlaceMember(String contentMarketPlaceMember) {
        this.contentMarketPlaceMember = contentMarketPlaceMember;
    }

    public String getJobType() {
        return JobType;
    }

    public void setJobType(String jobType) {
        JobType = jobType;
    }

    private String JobType;

    public String getEntityId() {
        return EntityId;
    }

    public void setEntityId(String entityId) {
        EntityId = entityId;
    }

    private String EntityId;

    public String getUniqueName() {
        return uniqueName;
    }

    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }

    private String uniqueName;

    public String getIdentifierValue() {
        return identifierValue;
    }

    public void setIdentifierValue(String identifierValue) {
        this.identifierValue = identifierValue;
    }

    public String getContentPublishingService() {
        return contentPublishingService;
    }

    public void setContentPublishingService(String contentPublishingService) {
        this.contentPublishingService = contentPublishingService;
    }

    public String getNamespace() {
        return namespace;
    }

    public String getRelationship() {
        System.out.println(selectrelationship);
        return selectrelationship;
    }

    public String getSelectObjectType() {
        return selectObjectType;
    }
    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getMajorVersion() {
        return majorVersion;
    }

    public void setMajorVersion(String majorVersion) {
        this.majorVersion = majorVersion;
    }

    public String getMinorVersion() {
        return minorVersion;
    }

    public void setMinorVersion(String minorVersion) {
        this.minorVersion = minorVersion;
    }

    public String getSourceNote() {
        return sourceNote;
    }

    public void setSourceNote(String sourceNote) {
        this.sourceNote = sourceNote;
    }

    public String getRevisionVersion() {
        return revisionVersion;
    }

    public void setRevisionVersion(String revisionVersion) {
        this.revisionVersion = revisionVersion;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getXmlNamespace() {
        return xmlNamespace;
    }

    public void setXmlNamespace(String xmlNamespace) {
        this.xmlNamespace = xmlNamespace;
    }

    public String getXmlSchema() {
        return xmlSchema;
    }

    public void setXmlSchema(String xmlSchema) {
        this.xmlSchema = xmlSchema;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getNametype1() {
        return nametype1;
    }

    public void setNametype1(String nametype1) {
        this.nametype1 = nametype1;
    }

    public String getLanguage1() {
        return language1;
    }

    public void setLanguage1(String language1) {
        this.language1 = language1;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getNametype2() {
        return nametype2;
    }

    public void setNametype2(String nametype2) {
        this.nametype2 = nametype2;
    }

    public String getLanguage2() {
        return language2;
    }

    public void setLanguage2(String language2) {
        this.language2 = language2;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getValueDomain() {
        return valueDomain;
    }

    public void setValueDomain(String ValueDomain) {
        this.valueDomain = valueDomain;
    }

    public String getDataElementKey() {
        return dataElementKey;
    }

    public void setDataElementKey(String DataElementKey) {
        this.dataElementKey = dataElementKey;
    }

    public String getDataType() {
        return datatype;
    }

    public void setDataType(String ValueDomain) {
        this.datatype = datatype;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String Owner) {
        this.owner = owner;
    }

    public String getRelationshipType() {
        return relationshipType;
    }

    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public String getObjectFromType() {
        return objectType;
    }

    public void setObjectFromType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectToType() {
        return objectType;
    }

    public void setObjectToType(String objectType) {
        this.objectType = objectType;
    }

    public String getIdentifierType() {
        return identifierType;
    }

    public void setIdentifierType(String identifierType) {
        this.identifierType = identifierType;
    }

}

