package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;

public class ValueDomainUtil {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));


    public void  fillValueDomainEntityDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        fillValueDomainDetails(driver,uniqueJobName,testData);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.findElement(entityDetails.selectNameType).click();
        if (testData.getNametype1().equals("LongName")) {
            driver.findElement(entityDetails.longname_dropdown).click();
            driver.findElement(entityDetails.selectLanguage).click();
            driver.findElement(entityDetails.language_dropdown).click();
            driver.findElement(entityDetails.name).sendKeys(testData.getName1());
            driver.findElement(entityDetails.save).click();
        }
        Util.sleep(DEFAULT_WAIT_TIME);
        if (testData.getNametype2().equals("Description")) {
            driver.findElement(entityDetails.addNameType).click();
            driver.switchTo().window(Util.switchToNewWindow(driver));
            Util.waitUntil(driver, entityDetails.selectNameType);
            Util.sleep(DEFAULT_WAIT_TIME);
            driver.findElement(entityDetails.selectNameType).click();
            driver.findElement(entityDetails.description_dropdown).click();
            driver.findElement(entityDetails.selectLanguage).click();
            driver.findElement(entityDetails.language_dropdown).click();
            driver.findElement(entityDetails.name).sendKeys(testData.getName2());
            driver.findElement(entityDetails.save).click();
        }

    }


    public void fillValueDomainDetails(WebDriver driver, String uniqueJobName, DIRBean testData){
        driver.findElement(entityDetails.entityUniqueName).sendKeys(uniqueJobName);
        Util.selectDataType(driver, driver.findElement(entityDetails.datatype), testData.getNamespace());
        Util.selectNamespace(driver, driver.findElement(entityDetails.namespace), testData.getNamespace());
        Util.selectOwner(driver,driver.findElement(entityDetails.owner), testData.getNamespace());
        //driver.findElement(entityDetails.sourceNote).sendKeys(testData.getSourceNote());
        driver.findElement(entityDetails.objectNames).click();
        driver.findElement(entityDetails.addNameType).click();
        Util.sleep(DEFAULT_WAIT_TIME);
    }


    public void fillValueDomainEntityWithoutFields(WebDriver driver, String uniqueJobName, DIRBean testData) {

        driver.findElement(entityDetails.entityUniqueName).sendKeys(uniqueJobName);
        Util.selectDataType(driver, driver.findElement(entityDetails.datatype), testData.getNamespace());
        Util.selectNamespace(driver, driver.findElement(entityDetails.namespace), testData.getNamespace());
        Util.selectOwner(driver,driver.findElement(entityDetails.owner), testData.getNamespace());

        driver.findElement(entityDetails.objectNames).click();
        driver.findElement(entityDetails.addNameType).click();
        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(DEFAULT_WAIT_TIME);
        driver.findElement(entityDetails.selectNameType).click();
        if (testData.getNametype1().equals("LongName")) {
            driver.findElement(entityDetails.longname_dropdown).click();
            driver.findElement(entityDetails.selectLanguage).click();
            driver.findElement(entityDetails.language_dropdown).click();
            driver.findElement(entityDetails.name).sendKeys(testData.getName1());
            driver.findElement(entityDetails.save).click();
        }
        Util.sleep(DEFAULT_WAIT_TIME);

    }

    public static void validateValueDomainMapping(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains("hasPermID>"));
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("rdf-schema#label>"));
        Assert.assertTrue(actualData.contains("cmp/uniqueName>"));
        Assert.assertTrue(actualData.contains("cmp/hasNamespace>"));
        Assert.assertTrue(actualData.contains("effectiveFrom>"));
        Assert.assertTrue(actualData.contains("type> <http://registry.ecp.ontology.thomsonreuters.com/NamedGraph>"));

    }

    public static void validateValueDomainModifiedMapping(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains("hasPermID>"));
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("rdf-schema#label>"));
        Assert.assertTrue(actualData.contains("cmp/uniqueName>"));
        Assert.assertTrue(actualData.contains("cmp/hasNamespace>"));
        Assert.assertTrue(actualData.contains("effectiveFrom>"));
        Assert.assertTrue(actualData.contains("type> <http://registry.ecp.ontology.thomsonreuters.com/NamedGraph>"));
        Assert.assertTrue(actualData.contains("srcNote>"));
    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }
}
