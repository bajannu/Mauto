package com.tr.dir.utils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.LoginPage;
import com.tr.dir.pages.ObjectMappingPage;
import org.apache.jena.base.Sys;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.File;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class UiUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));
    ObjectMappingPage objectMapping = new ObjectMappingPage();

    /**
     * Login to DIR
     *
     * @param driver
     * @param user
     * @param password
     */
    public WebDriver login(WebDriver driver, String user, String password) {

        String exePath = "src/test/resources/chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", exePath);
        driver = new ChromeDriver();
        /*  File exe = new File("src/test/resources/IEDriverServerX32.exe");
          System.setProperty("webdriver.ie.driver",exe.getAbsolutePath());
          System.out.println(exe.getAbsolutePath().toString());
          driver = new InternetExplorerDriver();
*/
        driver.get("http://" + Util.getProperty("UI_HOST") + "/metadatamanagement/defaultuserlogin.aspx");
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        LoginPage loginPage = new LoginPage();
        driver.findElement(loginPage.userId).sendKeys(user);
        driver.findElement(loginPage.password).sendKeys(password);
        driver.findElement(loginPage.login).click();
        Util.waitUntil(driver, loginPage.home);
        return driver;
    }

    public List<String> getAllObjectTypes(WebDriver driver) {
        List<String> objectTypes = new ArrayList<String>();

        int lastRowCount = driver.findElement(By.xpath("html/body/form/div[3]/div[5]/div[2]/div/table/tbody")).findElements(By.tagName("tr")).size();
        for (int i = 2; i <= lastRowCount; i++) {
            String objectType = driver.findElement(By.xpath(".//*[@id='ctl00_cpM_gridView']/tbody/tr[" + i + "]/td[2]")).getText();
            objectTypes.add(objectType);
        }
        System.out.println(objectTypes.toString());
        return objectTypes;
    }

    public void mapCreatedEntityToOtherService(WebDriver driver) {

        driver.switchTo().window(Util.switchToWindow(driver));
        driver.findElement(homePage.home).click();
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(homePage.rdfMapping)).build().perform();
        driver.findElement(homePage.ecpServiceMapping).click();
        Util.waitUntil(driver, entityDetails.serviceName);
        driver.findElement(entityDetails.serviceName).click();
        driver.findElement(entityDetails.addContentItem).click();
        driver.switchTo().window(Util.switchToNewWindow(driver));
        driver.findElement(entityDetails.entitySearchButton).click();
        Util.sleep(DEFAULT_WAIT_TIME);
        String latestContentEntityID = driver.findElement(entityDetails.getlatestContetEntityID).getText();
        driver.findElement(entityDetails.searchEntityId).sendKeys(latestContentEntityID);
        driver.findElement(entityDetails.entitySearchButton).click();
        driver.findElement(entityDetails.entityCheckBox).click();
        driver.findElement(entityDetails.mapSelectedItems).click();
    }

   /**
     * Get Last row number from ObjectMapping table to Add a record
     *
     * @param driver
     * @return
     */
    public String getLastRowCount(WebDriver driver) {
        int lastRowCount_Int = driver.findElement(By.xpath("html/body/form/div[3]/div[5]/div[3]/div/table/tbody")).findElements(By.tagName("tr")).size();
        return Integer.toString(lastRowCount_Int);
    }

    /**
     * Get existing property names from ObjectMapping page
     *
     * @param driver
     * @return listOfExistingPropertyNames
     */
    public Map<String, Integer> getExistingPropertyNames(WebDriver driver) {
        Map<String, Integer> existingPropertyNames = new HashMap<String, Integer>();
        int lastRowCount = Integer.parseInt(getLastRowCount(driver));
        System.out.println("lastRowCount"+lastRowCount);
        for (int i = 2; i <= lastRowCount - 2; i++) {
            String propertyName = driver.findElement(By.xpath(".//*[@id='ctl00_cpM_gridView']/tbody/tr[" + i + "]/td[5]")).getText();
            existingPropertyNames.put(propertyName, i);
        }
        return existingPropertyNames;
    }

    /**
     * Check whether given property is present, if exists then delete it
     *
     * @param driver
     * @param propertyName
     */
    public void deletePropertyIfExist(WebDriver driver, String propertyName) {
        Map<String, Integer> propertyNames = getExistingPropertyNames(driver);
        if (propertyNames.containsKey(propertyName) == true) {
            int indexOfRow = propertyNames.get(propertyName);
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + indexOfRow + "_lnkDelete")).click();
            Util.sleep(5);
        }
    }

    /**
     * Add given field
     *
     * @param driver
     * @param testData
     */
    public void addRDFMappingDetails(WebDriver driver, DIRBean testData) {
        deletePropertyIfExist(driver, testData.getPropertyName());
        String lastRowCount = getLastRowCount(driver);

        driver.findElement(By.id("ctl00_cpM_gridView_ctl" + lastRowCount + "_ddlPropertyName")).click();
        driver.findElement(By.xpath(".//*[@id='ctl00_cpM_gridView_ctl" + lastRowCount + "_ddlPropertyName']/option[21]")).click();
        driver.findElement(By.id("ctl00_cpM_gridView_ctl" + lastRowCount + "_btnAddRecord")).click();
        Util.sleep(DEFAULT_WAIT_TIME);
    }


    /**
     * Modify given field
     *
     * @param driver
     * @param testData
     */
    public void modifyRDFMappingDetails(WebDriver driver, DIRBean testData) {

        Map<String, Integer> propertyNames = getExistingPropertyNames(driver);
        int lastRowCount = Integer.parseInt(getLastRowCount(driver));
        System.out.println(propertyNames+"propertyNames"+"size"+propertyNames.size());
        if (propertyNames.containsKey(testData.getPropertyName()) == true) {
            int indexOfRow = propertyNames.get(testData.getPropertyName());
            String val = "";
            if (indexOfRow <= 9) {
                val = "0";
            }
            System.out.println(testData.getPropertyName() + "   " + indexOfRow);
            Util.waitUntil(driver,By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"));
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_lnkEdit")).click();
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_txtFormula")).clear();
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_txtFormula")).sendKeys(testData.getFormula());
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_lnkUpdate")).click();
            Util.waitUntil(driver,By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"));
        }
        else
        {
            int indexOfRow = lastRowCount;
            String val = "";
            if (indexOfRow <= 9) {
                val = "0";
            }
            System.out.println(testData.getPropertyName() + "   " + indexOfRow);
            Select objectName = new Select(driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_ddlObjectName")));
            objectName.selectByVisibleText(testData.getEntity().toString());
            Util.waitUntil(driver,By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"));
            Select propertyName = new Select(driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow +"_ddlPropertyName")));
            propertyName.selectByVisibleText(testData.getPropertyName());
            Util.waitUntil(driver,By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"));
            driver.findElement(By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_txtFormula")).sendKeys(testData.getFormula());
            Util.waitUntil(driver,By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"));
            driver.findElement((By.id("ctl00_cpM_gridView_ctl" + val + indexOfRow + "_btnAddRecord"))).click();
        }

    }

    public void clickElement(WebDriver driver, By locator) {
        driver.findElement(locator).click();
    }

    public void enterText(WebDriver driver, By locator, String text) {
        driver.findElement(locator).clear();
        driver.findElement(locator).sendKeys(text);
    }

    public String getText(WebDriver driver, By locator) {
        String errorMessage = driver.findElement(locator).getText();
        return errorMessage;
    }



    public void addNewObjectTypeMappingForEntity(WebDriver driver,DIRBean testData)
    {
        mouseHover(driver,homePage.rdfMapping);
        Util.waitUntil(driver, homePage.objectMapping);

        driver.findElement(homePage.objectMapping).click();
        Util.waitUntil(driver, objectMapping.objectType);

        Select options = new Select(driver.findElement(objectMapping.objectType));
        options.selectByVisibleText(testData.getEntity());
        Util.waitUntil(driver,objectMapping.objectType);

        driver.findElement(entityDetails.addNewEntity).click();
        Util.waitUntil(driver,objectMapping.objectType);
        modifyRDFMappingDetails(driver, testData);


      //  Select objectName = new Select(driver.findElement(objectMapping.objectForNamespace));
       // objectName.selectByVisibleText(testData.getEntity().toString());
       // Util.waitUntil(driver,objectMapping.addRecordForNamespace);
       // Select propertyName = new Select(driver.findElement(objectMapping.propertyNameForNamespace));
        //propertyName.selectByVisibleText(testData.getObjectTypeProperty());
        //Util.waitUntil(driver,objectMapping.addRecordForNamespace);
        //driver.findElement(objectMapping.formulaForNamespace).sendKeys(testData.getObjectTypeFormula());
        //driver.findElement(objectMapping.addRecordForNamespace).click();
        //Util.waitUntil(driver,objectMapping.objectType);
    }

    public void enterSourceNote(WebDriver driver,DIRBean testData)
    {
        driver.findElement(entityDetails.sourceNote).sendKeys(testData.getSourceNote());
    }

    public void enterComments(WebDriver driver,DIRBean testData)
    {
        driver.findElement(entityDetails.comments).sendKeys(testData.getComments());
    }

    public void enterUniqueName(WebDriver driver,DIRBean testData)
    {
        driver.findElement(entityDetails.entityUniqueName).sendKeys(testData.getUniqueName());
    }

    public void mouseHover(WebDriver driver,By locator)
    {
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(locator)).build().perform();
    }

    public void selectNameType(WebDriver driver,DIRBean testData,By locator)
    {
        if(testData.getJobType().equalsIgnoreCase("New"))
        {
            driver.switchTo().window(Util.switchToNewWindow(driver));

        }

        else if (testData.getJobType().equalsIgnoreCase("Existing"))
        {
            driver.switchTo().window(Util.switchToSecondWindow(driver));
        }
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(5);
        driver.findElement(entityDetails.selectNameType).click();
        selectOptionFromDropDownByLocator(driver,locator);
        driver.findElement(entityDetails.selectLanguage).click();
        driver.findElement(entityDetails.language_dropdown).click();
        driver.findElement(entityDetails.name).sendKeys(testData.getName1());
        driver.findElement(entityDetails.save).click();

    }
    public void addLongName(WebDriver driver, DIRBean testData) {
        clickElement(driver, entityDetails.longname_dropdown);
        clickElement(driver, entityDetails.selectLanguage);
        clickElement(driver, entityDetails.language_dropdown);
        enterText(driver, entityDetails.name, testData.getName1());
        clickElement(driver, entityDetails.save);
    }

    public void addDescription(WebDriver driver, DIRBean testData) {
        clickElement(driver, entityDetails.selectNameType);
        clickElement(driver, entityDetails.description_dropdown);
        clickElement(driver, entityDetails.selectLanguage);
        clickElement(driver, entityDetails.language_dropdown);
        enterText(driver, entityDetails.name, testData.getName2());
        clickElement(driver, entityDetails.save);
    }

    public void selectOptionFromDropDownByLocator(WebDriver driver, By locator)
    {
        WebElement myoption = driver.findElement(locator);
        myoption.click();
    }

    public void selectOptionFromDropDownByName(WebDriver driver, By locator,String name)
    {
        Select options = new Select(driver.findElement(locator));
        options.selectByVisibleText(name);
    }

    public void selectOptionFromDropDownByIndex(WebDriver driver, By locator,int index)
    {
        Select options = new Select(driver.findElement(locator));
        options.selectByIndex(index);

    }

}
