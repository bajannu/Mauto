package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;

public class ContentMarketplaceUtil extends UiUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));


    public void fillContentMarketplaceDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        selectNamespace(driver);
        clickElement(driver, entityDetails.objectNames);
        clickElement(driver, entityDetails.addNameType);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(5);
        driver.findElement(entityDetails.selectNameType).click();
        if (testData.getNametype1().equals("LongName")) {
            addLongName(driver, testData);
        }
        Util.sleep(5);
        driver.findElement(entityDetails.addNameType).click();
        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(5);
        if (testData.getNametype2().equals("Description")) {
            addDescription(driver, testData);
        }
        Util.sleep(5);
        clickElement(driver, entityDetails.fromRelationships);
        clickElement(driver, entityDetails.cmpRelationshipType);
        driver.switchTo().window(Util.switchToThirdWindow(driver));
        clickElement(driver, entityDetails.relationshipType);
        clickElement(driver, entityDetails.isPermissionedFor_RelationshipType);
        clickElement(driver, entityDetails.objectToType);
        clickElement(driver, entityDetails.testSegmentation_ObjType);
        enterText(driver, entityDetails.toObjectId, Util.getProperty("OBJECT_ID_CMP"));
    }

    public void selectNamespace(WebDriver driver) {
        clickElement(driver, entityDetails.namespace);
        clickElement(driver, entityDetails.namespaceValue);
    }

    public void validateContentMarketplaceData(String entityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains(entityId), "Generated rdf is not having created entityID !!");
        Assert.assertTrue(actualData.contains("hasNamespace> <ecp:9"), "Generated rdf is not having Namespace field !!");
        //Assert.assertTrue(actualData.contains("<ecp:srcNote"), "Generated rdf is not having SrcNote field !!");

    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }
}