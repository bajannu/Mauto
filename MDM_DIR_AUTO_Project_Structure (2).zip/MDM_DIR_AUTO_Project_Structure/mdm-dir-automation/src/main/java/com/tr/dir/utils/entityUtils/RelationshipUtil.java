package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.pages.ObjectTypeMappingPage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class RelationshipUtil extends UiUtils {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));

    public void fillRelationshipDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {

        Util.selectRelationshipType(driver, driver.findElement(entityDetails.relationshipType), testData.getRelationship());
        Util.selectFromObjectType(driver, driver.findElement(entityDetails.objectFromType), testData.getSelectObjectType());
        enterText(driver, entityDetails.objectIDFromField, Util.getPropertyEntity("CONTENT_MARKETPLACE_ENTITY_ID","cmp"));
        Util.selectToObjectType(driver, driver.findElement(entityDetails.objectToType),testData.getObjectToType());
        enterText(driver, entityDetails.objectIDToField, Util.getPropertyEntity("VALUE_DOMAIN_ENUMERATION_ENTITY_ID","valuedomain"));
     }

    public static void validateRelationshipMapping(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains("hasPermID>"));
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("rdf-schema#label>"));
        Assert.assertTrue(actualData.contains("isObjectified> \"false\""));
        Assert.assertTrue(actualData.contains("#type> <http://registry.ecp.ontology.thomsonreuters.com/cmp/RelationshipType>"));
        Assert.assertTrue(actualData.contains("<ecp:relTypeIsUniversal> \"false\""));
        Assert.assertTrue(actualData.contains("effectiveFrom>"));
        Assert.assertTrue(actualData.contains("type> <http://registry.ecp.ontology.thomsonreuters.com/NamedGraph>"));

    }

    public static void validateRelationshipModifiedMapping(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains("hasPermID>"));
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("rdf-schema#label>"));
        Assert.assertTrue(actualData.contains("isObjectified> \"false\""));
        Assert.assertTrue(actualData.contains("#type> <http://registry.ecp.ontology.thomsonreuters.com/cmp/RelationshipType>"));
        Assert.assertTrue(actualData.contains("<ecp:relTypeIsUniversal> \"false\""));
        Assert.assertTrue(actualData.contains("effectiveFrom>"));
        Assert.assertTrue(actualData.contains("type> <http://registry.ecp.ontology.thomsonreuters.com/NamedGraph>"));
        Assert.assertTrue(actualData.contains("srcNote>"));
    }
}
