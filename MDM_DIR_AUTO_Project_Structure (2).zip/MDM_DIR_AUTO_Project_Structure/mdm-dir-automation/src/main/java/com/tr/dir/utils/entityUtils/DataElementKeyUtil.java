package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.UiUtils;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;

public class DataElementKeyUtil {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));

    public void fillDataElementKeyDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        UiUtils uiUtils = new UiUtils();
        driver.switchTo().window(Util.switchToNewWindow(driver));
        uiUtils.enterText(driver, entityDetails.entityUniqueName, uniqueJobName);
        uiUtils.enterText(driver, entityDetails.dataElementName, testData.getName1());
        Util.selectNamespace(driver, driver.findElement(entityDetails.namespace), testData.getNamespace());
        uiUtils.clickElement(driver, entityDetails.dataElementsTab);
        uiUtils.clickElement(driver, entityDetails.addDataElements);
        Util.switchToWindow(driver);
        uiUtils.enterText(driver, entityDetails.dataElementId, Util.getProperty("DATA_ELEMENT_ENTITY_ID"));
        uiUtils.clickElement(driver, entityDetails.saveDataElement);
        Util.switchToWindow(driver);
    }

    public static void validateDataElementKey(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("effectiveFrom> \""));
        Assert.assertTrue(actualData.contains("hasDimensionDataElement>"));
        Assert.assertTrue(actualData.contains(testData.getName1()));
        Assert.assertTrue(actualData.contains("QED_Auto"));

    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }
}
