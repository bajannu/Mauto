package com.tr.dir.utils.entityUtils;

import com.tr.dir.bean.DIRBean;
import com.tr.dir.pages.EntityDetailsPage;
import com.tr.dir.pages.HomePage;
import com.tr.dir.utils.Util;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;

public class DataElementUtil {

    EntityDetailsPage entityDetails = new EntityDetailsPage();
    HomePage homePage = new HomePage();
    int DEFAULT_WAIT_TIME = Integer.parseInt(Util.getProperty("DEFAULT_WAIT_TIME"));


    public void fillDataElementEntityDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        fillDataElementDetails(driver, uniqueJobName, testData);

        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, entityDetails.selectNameType);
        Util.sleep(5);
        driver.findElement(entityDetails.selectNameType).click();
        if (testData.getNametype1().equals("LongName")) {
            driver.findElement(entityDetails.longname_dropdown).click();
            driver.findElement(entityDetails.selectLanguage).click();
            driver.findElement(entityDetails.language_dropdown).click();
            driver.findElement(entityDetails.name).sendKeys(testData.getName1());
            driver.findElement(entityDetails.save).click();
        }
        Util.sleep(5);
        if (testData.getNametype2().equals("Description")) {
            driver.findElement(entityDetails.addNameType).click();
            driver.switchTo().window(Util.switchToNewWindow(driver));
            Util.waitUntil(driver, entityDetails.selectNameType);
            Util.sleep(5);
            driver.findElement(entityDetails.selectNameType).click();
            driver.findElement(entityDetails.description_dropdown).click();
            driver.findElement(entityDetails.selectLanguage).click();
            driver.findElement(entityDetails.language_dropdown).click();
            driver.findElement(entityDetails.name).sendKeys(testData.getName2());
            driver.findElement(entityDetails.save).click();
        }

    }

    public void fillDataElementDetails(WebDriver driver, String uniqueJobName, DIRBean testData) {
        driver.findElement(entityDetails.entityUniqueName).sendKeys(uniqueJobName);
        if (testData.getNamespace()!=null) {
            Util.selectNamespace(driver, driver.findElement(entityDetails.namespace), testData.getNamespace());
        }
        Util.selectContentPublishingService(driver, driver.findElement(entityDetails.contentPublishingService), testData.getContentPublishingService());
        Util.selectValueDomain(driver, driver.findElement(entityDetails.valueDomain), testData.getNamespace());
        Util.selectDataElementKey(driver, driver.findElement(entityDetails.dataElementKey), testData.getNamespace());
        driver.findElement(entityDetails.sourceNote).sendKeys(testData.getSourceNote());
        driver.findElement(entityDetails.objectNames).click();
        driver.findElement(entityDetails.addNameType).click();
        Util.sleep(3);
    }

    public static void validateDataElement(String createdEntityId, String actualData, DIRBean testData) {
        Assert.assertTrue(actualData.contains(createdEntityId));
        Assert.assertTrue(actualData.contains("<ecp:srcNote>"));
        Assert.assertTrue(actualData.contains("isCalculable>"));
        Assert.assertTrue(actualData.contains("hasContentPublishingService"));
        Assert.assertTrue(actualData.contains("hasCurrency>"));
        Assert.assertTrue(actualData.contains("hasLanguage>"));
        Assert.assertTrue(actualData.contains("hasScale>"));
        Assert.assertTrue(actualData.contains("isNullable>"));
        Assert.assertTrue(actualData.contains("hasNamespace>"));

    }

    public static void validateDBObjectTypeMapping(ArrayList<String> objectTypeMappingList, String actualData) {

        for (String strTemp : objectTypeMappingList){
            Assert.assertTrue(actualData.contains(strTemp));
            //System.out.println(strTemp);
        }
    }
}
