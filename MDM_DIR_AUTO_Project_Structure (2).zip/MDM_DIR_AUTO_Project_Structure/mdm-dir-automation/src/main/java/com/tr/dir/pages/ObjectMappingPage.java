package com.tr.dir.pages;

import org.openqa.selenium.By;

public class ObjectMappingPage {

    public By objectType = By.id("ctl00_cpM_drpBOType");
    public By contentItemObjectType = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[3]");
    public By addObjectMapping = By.id("ctl00_cpM_btnNew");
    public By addRecord = By.id("ctl00_cpM_gridView_ctl26_btnAddRecord");
    public By selectPropertyName = By.id("ctl00_cpM_gridView_ctl27_ddlPropertyName");
    public By commentsPropertyName = By.xpath(".//*[@id='ctl00_cpM_gridView_ctl27_ddlPropertyName']/option[2]");
    public By propertyValue = By.id("ctl00_cpM_gridView_ctl26_txtRDFURI");
    public By formula = By.id("ctl00_cpM_gridView_ctl26_txtFormula");
    public By commodity = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[2]");
    public By dataElementObjectType = By.xpath(".//*[@id='ctl00_cpM_drpBOType']/option[6]");
    public By relationshipTypeObjectType = By.xpath(".//*[@id='ctl00_cpM_drpBOType']/option[13]");
    public By identifierTypeObjectType = By.xpath(".//*[@id='ctl00_cpM_drpBOType']/option[9]");
    public By valueDomainObjectType = By.xpath(".//*[@id='ctl00_cpM_drpBOType']/option[14]");
    public By contentMarketplaceMember = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[4]");
    public By contentPublishingService = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[5]");
    public By dataElement = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[6]");
    public By dataElementKey = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[7]");
    public By identifier = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[8]");
    public By identifierType = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[9]");
    public By namespaceObjectType = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[10]");
    public By presentationCategory = By.xpath("//*[@id='ctl00_cpM_drpBOType']/option[11]");

    public By addRecordForNamespace = By.id("ctl00_cpM_gridView_ctl05_btnAddRecord");
    public By objectForNamespace = By.id("ctl00_cpM_gridView_ctl05_ddlObjectName");
    public By propertyNameForNamespace = By.id("ctl00_cpM_gridView_ctl05_ddlPropertyName");
    public By formulaForNamespace = By.id("ctl00_cpM_gridView_ctl05_txtFormula");



}
