package com.tr.dir.pages;

import com.tr.dir.utils.Util;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EntityDetailsPage {

    public By selectExistingJob = By.id("ctl00_cpM_addEntityToJobCtrl_rbtnSelectJob");
    public By entityType = By.id("ctl00_cpM_drpBOType");
    public By entityID = By.id("ctl00_cpM_txtEntityID");
    public By entityNameType = By.id("ctl00_cpM_drpNameType");
    public By identifierType = By.id("ctl00_cpM_drpOwnIdentifierType");
    public By identifierTypedropdown = By.id("ctl00_cpM_eC_drpIDType");
    public By identifierobjectType = By.id("ctl00_cpM_eC_drpObjectType");
    public By selectObjectID = By.id("ctl00_cpM_eC_txtObjectID");
    public By entityName = By.id("ctl00_cpM_txtNameKeyword");
    public By identifierValue = By.id("ctl00_cpM_txtIdentifierValue");
    public By identifierIDValue = By.id("ctl00_cpM_eC_txtIDValue");
    public By language = By.id("ctl00_cpM_drpLanguage");
    public By search = By.id("ctl00_cpM_btnSearch");
    public By entityUniqueName = By.id("ctl00_cpM_eC_txtUnqName");
    public By addNewEntity = By.id("ctl00_cpM_btnNew");
    public By identifierTypeAllCodes = By.xpath(".//*[@id='ctl00_cpM_eC_drpIDType']/option[3]");

    public By editEntity = By.id("ctl00_commandBar_ctl00_btnEdit");
    public By entityID2 = By.id("ctl00_cpM_eC_txtEntityID");
    public By uniqueName = By.id("ctl00_cpM_eC_txtUnqName");

    public By jobName = By.id("ctl00_addEntityToJobCtrl_txtJobName");
    public By jobName2 = By.id("ctl00_cpM_addEntityToJobCtrl_txtJobName");
    public By jobType = By.id("ctl00_cpM_addEntityToJobCtrl_drpJobType");
    public By next = By.id("ctl00_addEntityToJobCtrl_btnNew");
    public By next2 = By.id("ctl00_cpM_addEntityToJobCtrl_btnNew");
    public By sourceNote = By.id("ctl00_cpM_eC_txtSourceNote");
    public By comments = By.id("ctl00_cpM_eC_txtComments");
    public By contentPublishingService = By.id("ctl00_cpM_eC_drpCPS_drpBO");
    public By relationshipType = By.id("ctl00_cpM_eC_drpRelType");
    public By objectFromType = By.id("ctl00_cpM_eC_drpFromObjectType");
    public By objectToType = By.id("ctl00_cpM_eC_drpToObjectType");
    //public By contentPublishingService = By.xpath("//select[@id='ctl00_cpM_eC_drpCPS_drpBO']");
    public By namespace = By.id("ctl00_cpM_eC_drpNamespace_drpBO");
    public By majorVersion = By.id("ctl00_cpM_eC_txtMajorVersion");
    public By minorVersion = By.id("ctl00_cpM_eC_txtMinorVersion");
    public By revisionVersion = By.id("ctl00_cpM_eC_txtRevisionVersion");
    public By xmlNamespace = By.id("ctl00_cpM_eC_txtXmlNamespace");
    public By xmlSchema = By.id("ctl00_cpM_eC_txtXmlSchema");
    public By sendToJob = By.id("ctl00_commandBar_ctl00_btnSave");

    public By objectNames = By.xpath(".//*[@id='ctl00_cpM_liNames']/a");
    public By objectIDFromField = By.id("ctl00_cpM_eC_txtFromObjectID");
    public By objectIDToField = By.id("ctl00_cpM_eC_txtToObjectID");
    public By objectIDFrom = By.id("ctl00_cpM_eC_linkFromSearch");
    public By objectIDSearch = By.xpath(".//*[@id='ctl00_cpM_eC_linkSearch']/a");
    public By objectIDSearchCss = By.cssSelector("img[title=\"Search objects of specific Identifier Object Type\"]");
    public By objectIDTo = By.xpath(".//*[@id='ctl00_cpM_eC_linkToSearch']/a");
    public By objectSearch = By.id("ctl00_cpM_btnSearch");
    public By objectListSelect1 = By.id("ctl00_cpM_gridView_ctl02_linkSelect");
    public By objectListSelect2 = By.xpath(".//*[@id='ctl00_cpM_gridView_ctl03_linkSelect']/a");
    public By viewNameLogic = By.xpath(".//*[@id='ctl00_cpM_liViewObjectNames']/a");
    public By viewNamePairs = By.xpath(".//*[@id='ctl00_cpM_liViewNames']/a");
    public By addNameType = By.id("ctl00_cpM_nameListCtrl_imgAddName");

    public By selectNameType = By.id("ctl00_cpM_nameListCtrl_drpNameType_drpBO");
    public By selectLanguage = By.id("ctl00_cpM_nameListCtrl_drpLanguage_drpBO");
    public By name = By.id("ctl00_cpM_nameListCtrl_txtName");
    public By save = By.id("ctl00_cpM_nameListCtrl_btnSaveName");
    public By longname_dropdown = By.xpath(".//*[@id='ctl00_cpM_nameListCtrl_drpNameType_drpBO']/option[16]");
    public By language_dropdown = By.xpath(".//*[@id='ctl00_cpM_nameListCtrl_drpLanguage_drpBO']/option[2]");
    public By description_dropdown = By.xpath(".//*[@id='ctl00_cpM_nameListCtrl_drpNameType_drpBO']/option[11]");

    public By validateApprove = By.id("ctl00_cpM_btnOneClick");

    public By serviceName = By.xpath(".//*[@id='ctl00_cpM_lbServiceID']/option");
    public By searchContentItem = By.id("ctl00_cpM_txtEntitySearch");
    public By addContentItem = By.id("ctl00_cpM_imgAdd");
    public By searchButton = By.id("ctl00_cpM_btnEntitySearch");
    public By searchEntityId = By.id("ctl00_cpM_txtEntityID");
    public By entitySearchButton = By.id("ctl00_cpM_btnSearch");
    public By getlatestContetEntityID = By.xpath(".//*[@id=\"ctl00_cpM_gridView\"]/tbody/tr[2]/td[3]");
    public By entityCheckBox = By.id("ctl00_cpM_gridView_ctl02_chkSelect");
    public By mapSelectedItems = By.id("ctl00_cpM_btnMapSelectedItems");
    public By errorMessage = By.xpath(".//*[@id='ctl00_cpM_vsContentItem']/ul/li");
    public By relationshipTypeErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsRelationshipType']/ul/li[2]");
    public By identifierErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsIdentifier']/ul/li");
    public By identifierTypeErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsIdentifierType']/ul/li[2]");
    public By valueDomainerrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsValueDomain']/ul/li[2]");
    public By generalEntitySearch = By.id("ctl00_cpM_txtEntityID");
    public By dataElementErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsDataElement']/ul/li[1]");
    public By dataElementKeyErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsDataElementKey']/ul/li");
    public By cpsErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsCPS']/ul/li");
    public By cmpErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsCMM']/ul/li");
    public By relationshipErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsRelationship']/ul/li");
    public By selectAJob = By.id("ctl00_cpM_ctl00_ctl00_gridViewJobs_ctl02_linkSelectAJob");
    public By existingJobCheckbox = By.id("ctl00_addEntityToJobCtrl_rbtnSelectJob");
    public By valueDomain = By.id("ctl00_cpM_eC_drpVD_drpBO");
    public By dataElementKey = By.id("ctl00_cpM_eC_drpDEKey_drpBO");
    public By datatype=By.id("ctl00_cpM_eC_drpDataType_drpBO");
    public By owner=By.id("ctl00_cpM_eC_drpOwner_drpBO");
    public By identifier=By.xpath(".//*[@id='ctl00_cpM_liIdentifiers']/a");
    public By identifierTypeCreate=By.id("ctl00_cpM_identifierListCtrl_imgAddIdentifier");
    public By selectEntity=By.id("ctl00_cpM_gridView_ctl02_linkUniqueName");
    public By isNullable=By.id("ctl00_cpM_eC_chkIsNullable");
    public By dataElementName=By.id("ctl00_cpM_eC_txtName");
    public By dataElementsTab=By.xpath(".//*[@id='ctl00_cpM_liDataElementKeyDimension']/a");
    public By addDataElements=By.id("ctl00_cpM_dataElementKeyDimensionListCtrl_imgAddDataElementKeyDimension");
    public By dataElementId=By.id("ctl00_cpM_dataElementKeyDimensionListCtrl_txtDataElementID");
    public By saveDataElement=By.id("ctl00_cpM_dataElementKeyDimensionListCtrl_btnSaveDataElementKeyDimension");
    public By contentMarketPlaceMember=By.id("ctl00_cpM_eC_drpCMM_drpBO");
    public By brokersCMP=By.id("ctl00_cpM_eC_drpCMM_drpBO");
    public By identifierSelectResult=By.id("ctl00_cpM_gridView_ctl02_linkIdentifierID");
    public By relationshipTypeSelectResult=By.id("ctl00_cpM_gridView_ctl02_linkUniqueName");
    public By relTypeSourceNote =By.id("ctl00_cpM_eC_txtSourceNote");
    public By relationshipSelectResult=By.id("ctl00_cpM_gridView_ctl02_linkRelationshipID");
    public By errorMessageMissingDescriptionToCreateNamespace = By.xpath(".//*[@id='ctl00_cpM_vsNamespace']/ul/li[3]");
    public By errorMessageMissingLongNameToCreateNamespace = By.xpath(".//*[@id='ctl00_cpM_vsNamespace']/ul/li[2]");
    public By getJobId = By.id("ctl00_cpM_txtJobID");
    public By enterJobIdInJobManagementPage = By.id("ctl00_cpM_ctl00_ctl00_txtJobID");
    public By processingStateOfTheSearchedJobId = By.xpath(".//*[@id='ctl00_cpM_ctl00_ctl00_gridViewJobs_ctl02_lblStatus']");
    public By existingJobSearchButton = By.id("ctl00_cpM_ctl00_ctl00_btnSearchJobs");
    public By longNameByXpath = By.xpath("//Select[@id='ctl00_cpM_nameListCtrl_drpNameType_drpBO']/option[normalize-space(text())='LongName']");
    public By descriptionByXpath = By.xpath("//Select[@id='ctl00_cpM_nameListCtrl_drpNameType_drpBO']/option[normalize-space(text())='Description']");
    public By shortNameByXpath = By.xpath("//Select[@id='ctl00_cpM_nameListCtrl_drpNameType_drpBO']/option[normalize-space(text())='ShortName']");

    //valueDomainEnumeration
    public By valueDomainDropdown = By.id("ctl00_cpM_eC_drpVD_drpBO");
    public By errorMessageMissingValueDomainFieldToCreateValueDomainEnumeration = By.xpath(".//*[@id='ctl00_cpM_vsVDE']/ul/li");

    //Registered Data Type
    public By descriptionTextBox = By.id("ctl00_cpM_eC_txtDescription");
    public By getErrorMessageForMissingDescriptionForRegisteredDataType = By.id("ctl00_cpM_vsDataType");

    public By getErrorMessageForMissingUniqueNameForPresentationCategory = By.id("ctl00_cpM_vsPresentationCategory");
    public By getErrorMessageForMissingDescriptionForPresentationCategory = By.xpath(".//*[@id='ctl00_cpM_vsPresentationCategory']/ul/li[3]");
    public By getErrorMessageForMissingLongNameForPresentationCategory = By.xpath(".//*[@id='ctl00_cpM_vsPresentationCategory']/ul/li[2]");

    public By cipName = By.id("ctl00_cpM_eC_txtName");
    public By cipCIId = By.id("ctl00_cpM_eC_txtContentItemID");
    public By cipPublishingServiceId = By.id("ctl00_cpM_eC_txtContentPublishingServiceID");
    public By style = By.id("ctl00_cpM_eC_drpPubStyle_drpBO");
    public By styleValue = By.xpath(".//*[@id='ctl00_cpM_eC_drpPubStyle_drpBO']/option[4]");
    public By cipFrequency = By.id("ctl00_cpM_eC_drpFrequency_drpBO");
    public By cipFrequencyValue = By.xpath(".//*[@id='ctl00_cpM_eC_drpFrequency_drpBO']/option[4]");
    public By cipPartitionType = By.id("ctl00_cpM_eC_drpPartitionType");
    public By cipPartitionTypeValue = By.xpath(".//*[@id='ctl00_cpM_eC_drpPartitionType']/option[19]");
    public By cipPartition = By.id("ctl00_cpM_eC_drpPartition");
    public By cipPartitionValue = By.xpath(".//*[@id='ctl00_cpM_eC_drpPartition']/option[16]");
    public By cipErrorMessage = By.xpath(".//*[@id='ctl00_cpM_vsContentItemPublication']/ul/li[1]");
    public By namespaceValue = By.xpath(".//*[@id='ctl00_cpM_eC_drpNamespace_drpBO']/option[2]");
    public By fromRelationships = By.xpath(".//*[@id='ctl00_cpM_liFromRelationships']/a");
    public By addRelationshipType = By.id("ctl00_cpM_fromRelationshipListCtrl_imgAddFromRel");
    public By isPermissionedFor_RelationshipType = By.xpath(".//*[@id='ctl00_cpM_eC_drpRelType']/option[3]");
    public By testSegmentation_ObjType = By.xpath(".//*[@id='ctl00_cpM_eC_drpToObjectType']/option[3]");
    public By toObjectId = By.id("ctl00_cpM_eC_txtToObjectID");
    public By cmpRelationshipType = By.id("ctl00_cpM_fromRelationshipListCtrl_imgAddFromRel");

    public By identifierTypeSelectResult = By.id("ctl00_cpM_gridView_ctl02_linkUniqueName");
    public By valueDomainSelectResult = By.id("ctl00_cpM_gridView_ctl02_linkUniqueName");
    public By fromObjectIdSearchIcon = By.xpath(".//*[@id='ctl00_cpM_eC_linkFromSearch']/img");
    public By toObjectIdSearchIcon = By.xpath(".//*[@id='ctl00_cpM_eC_linkToSearch']/img");



    public void createNewJob(WebDriver driver, String uniqueJobName){
        driver.switchTo().window(Util.switchToWindow(driver));
        Util.waitUntil(driver, jobName);
        driver.findElement(jobName).sendKeys(uniqueJobName);
        next(driver);
        driver.switchTo().window(Util.switchToNewWindow(driver));
    }
    public void createNewJobforExisitingEntity(WebDriver driver, String uniqueJobName){
        driver.switchTo().window(Util.switchToNewWindow(driver));
        Util.waitUntil(driver, jobName);
        driver.findElement(jobName).sendKeys(uniqueJobName);
        next(driver);
        driver.switchTo().window(Util.switchToNewWindow(driver));
    }
    public void next(WebDriver driver){
        driver.findElement(next).click();
        Util.sleep(5);
    }

    public void sendToJob(WebDriver driver) {
        Util.sleep(8);
        driver.findElement(sendToJob).click();
        Util.sleep(8);
    }

    public void validateAndApprovrJob(WebDriver driver) {
        driver.switchTo().window(Util.switchToNewWindow(driver));
        driver.findElement(validateApprove).click();
        Util.sleep(15);
        driver.close();
    }


}
