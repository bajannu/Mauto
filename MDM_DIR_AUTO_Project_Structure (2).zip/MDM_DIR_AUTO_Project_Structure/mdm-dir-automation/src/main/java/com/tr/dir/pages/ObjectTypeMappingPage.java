package com.tr.dir.pages;

import org.openqa.selenium.By;

public class ObjectTypeMappingPage {

    public By createObjectTypeMapping = By.id("ctl00_cpM_btnNew");


}
